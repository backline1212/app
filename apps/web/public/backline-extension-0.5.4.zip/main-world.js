"use strict";
(() => {
  // ../widget/src/diagnostics.ts
  var MAX_ENTRIES = 50;
  var MAX_MESSAGE = 1e3;
  var consoleEntries = [];
  var networkEntries = [];
  var listeners = /* @__PURE__ */ new Set();
  var SECRET_PATTERNS = [
    [/\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g, "[token]"],
    [/\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}/gi, "$1 [redacted]"],
    [/(["']?\b(?:access[_-]?token|refresh[_-]?token|id[_-]?token|token|api[_-]?key|apikey|secret|client[_-]?secret|password|passwd|pwd|session(?:[_-]?id)?|auth(?:orization)?|signature|sig|code)\b["']?\s*[:=]\s*["']?)([^"'\s&,;}]+)/gi, "$1[redacted]"],
    [/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, "[email]"]
  ];
  function scrubText(text) {
    let result = text;
    for (const [pattern, replacement] of SECRET_PATTERNS) result = result.replace(pattern, replacement);
    return result;
  }
  function stripUrl(raw) {
    try {
      const url = new URL(raw, location.href);
      return scrubText(`${url.origin}${url.pathname}`);
    } catch {
      return scrubText(raw.split(/[?#]/, 1)[0]);
    }
  }
  function describe(value) {
    if (value instanceof Error) return `${value.name}: ${value.message}`;
    if (typeof value === "string") return value;
    if (value === void 0) return "undefined";
    try {
      const json = JSON.stringify(value);
      return json === void 0 ? String(value) : json;
    } catch {
      return String(value);
    }
  }
  function notify() {
    for (const listener of listeners) {
      try {
        listener();
      } catch {
      }
    }
  }
  function recordDiagnostic(entry) {
    if (entry.kind === "console") {
      const message = scrubText(String(entry.message ?? "")).slice(0, MAX_MESSAGE);
      if (!message) return;
      consoleEntries.push({ level: entry.level === "warn" ? "warn" : "error", message, at: entry.at });
      if (consoleEntries.length > MAX_ENTRIES) consoleEntries.shift();
    } else {
      networkEntries.push({
        method: String(entry.method || "GET").toUpperCase().slice(0, 16),
        url: stripUrl(String(entry.url ?? "")).slice(0, 2e3),
        status: Math.max(0, Math.min(999, Math.round(Number(entry.status) || 0))),
        duration_ms: entry.duration_ms == null ? null : Math.max(0, Math.round(entry.duration_ms)),
        at: entry.at
      });
      if (networkEntries.length > MAX_ENTRIES) networkEntries.shift();
    }
    notify();
  }
  var installed = false;
  function installDiagnosticsCapture(options = {}) {
    if (installed) return;
    installed = true;
    const emit = options.emit ?? recordDiagnostic;
    const now = () => (/* @__PURE__ */ new Date()).toISOString();
    const ignore = options.ignoreUrlPrefix ? new URL(options.ignoreUrlPrefix, location.href).href : null;
    const ownRequest = (url) => {
      if (!ignore) return false;
      try {
        return new URL(url, location.href).href.startsWith(ignore);
      } catch {
        return false;
      }
    };
    for (const level of ["error", "warn"]) {
      const original = console[level];
      console[level] = function(...args) {
        try {
          const message = args.map(describe).join(" ");
          if (!message.includes("[Backline]")) emit({ kind: "console", level, message, at: now() });
        } catch {
        }
        return original.apply(this, args);
      };
    }
    window.addEventListener("error", (event) => {
      if (event.error || event.message) {
        const where = event.filename ? ` (${stripUrl(event.filename)}:${event.lineno})` : "";
        emit({ kind: "console", level: "error", message: `Uncaught ${describe(event.error ?? event.message)}${where}`, at: now() });
      }
    });
    window.addEventListener("unhandledrejection", (event) => {
      emit({ kind: "console", level: "error", message: `Unhandled rejection: ${describe(event.reason)}`, at: now() });
    });
    const originalFetch = window.fetch;
    if (typeof originalFetch === "function") {
      window.fetch = async function(input, init) {
        const started = performance.now();
        const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
        const method = init?.method ?? (input instanceof Request ? input.method : "GET");
        try {
          const response = await originalFetch.call(this, input, init);
          if (response.status >= 400 && !ownRequest(url)) {
            emit({ kind: "network", method, url, status: response.status, duration_ms: performance.now() - started, at: now() });
          }
          return response;
        } catch (error) {
          if (!ownRequest(url) && !(error instanceof DOMException && error.name === "AbortError")) {
            emit({ kind: "network", method, url, status: 0, duration_ms: performance.now() - started, at: now() });
          }
          throw error;
        }
      };
    }
    const open = XMLHttpRequest.prototype.open;
    const send = XMLHttpRequest.prototype.send;
    const meta = /* @__PURE__ */ new WeakMap();
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      meta.set(this, { method, url: String(url), started: 0 });
      return open.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(body) {
      const info = meta.get(this);
      if (info) {
        info.started = performance.now();
        let aborted = false;
        this.addEventListener("abort", () => {
          aborted = true;
        });
        this.addEventListener("loadend", () => {
          if (!aborted && (this.status >= 400 || this.status === 0) && !ownRequest(info.url)) {
            emit({ kind: "network", method: info.method, url: info.url, status: this.status, duration_ms: performance.now() - info.started, at: now() });
          }
        });
      }
      return send.call(this, body);
    };
  }

  // src/main-world.ts
  var marker = window;
  if (!marker.__backlineDiagnostics) {
    marker.__backlineDiagnostics = true;
    installDiagnosticsCapture({
      emit: (entry) => window.postMessage({ __backlineDiagnostic: true, entry }, location.origin)
    });
  }
})();
