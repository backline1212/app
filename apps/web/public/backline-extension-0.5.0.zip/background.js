// src/lib/storage.ts
var STORAGE_KEY = "backline:connection";
async function getConnection() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  return result[STORAGE_KEY] ?? null;
}
async function setConnection(connection) {
  await chrome.storage.local.set({ [STORAGE_KEY]: connection });
}
async function clearConnection() {
  await chrome.storage.local.remove(STORAGE_KEY);
}

// src/lib/config.ts
var API_BASE_URL = "https://backlinewidget-production.up.railway.app";
var DASHBOARD_BASE_URL = "https://backline-qa.vercel.app";

// src/native-review.ts
var key = (tabId) => `review:${tabId}`;
var dashboardOrigin = new URL(DASHBOARD_BASE_URL).origin;
var origin = (url) => new URL(url).origin;
var activationGeneration = 0;
var reviewEpoch = 0;
var readyWaiters = /* @__PURE__ */ new Map();
var sessionWriters = /* @__PURE__ */ new Map();
var NativeReviewError = class extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
};
function waitForReady(launchId) {
  let timer;
  const ready = new Promise((resolve) => {
    readyWaiters.set(launchId, () => {
      clearTimeout(timer);
      readyWaiters.delete(launchId);
      resolve(true);
    });
    timer = setTimeout(() => {
      readyWaiters.delete(launchId);
      resolve(false);
    }, 15e3);
  });
  return { ready, cancel: () => {
    clearTimeout(timer);
    readyWaiters.delete(launchId);
  } };
}
async function read(tabId) {
  return (await chrome.storage.session.get(key(tabId)))[key(tabId)] ?? null;
}
async function mutateSession(tabId, change) {
  const operation = (sessionWriters.get(tabId) ?? Promise.resolve()).then(async () => {
    const next = change(await read(tabId));
    if (next === void 0) return false;
    if (next === null) await chrome.storage.session.remove(key(tabId));
    else await chrome.storage.session.set({ [key(tabId)]: next });
    return true;
  });
  const tail = operation.then(() => void 0, () => void 0);
  sessionWriters.set(tabId, tail);
  try {
    return await operation;
  } finally {
    if (sessionWriters.get(tabId) === tail) sessionWriters.delete(tabId);
  }
}
async function request(auth, path, init = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      credentials: "omit",
      headers: {
        ...init.body instanceof FormData ? {} : { "Content-Type": "application/json" },
        ...auth.kind === "member" ? { Authorization: `Bearer ${auth.token}` } : { "X-Guest-Session": auth.token }
      }
    });
  } catch (error) {
    if (init.signal?.aborted) throw error;
    throw new NativeReviewError("Can't reach Backline right now. This website review will stay open and retry.", 503);
  }
  if (!response.ok) {
    if (response.status === 404 && response.headers.get("x-railway-fallback") === "true") {
      throw new NativeReviewError("Backline is temporarily unavailable. Your review will stay open; try again shortly.", 503);
    }
    const body = await response.json().catch(() => null);
    throw new NativeReviewError(response.status === 401 ? "Review access expired. Return to Backline and open browser review again." : body?.error?.message ?? `Backline request failed (${response.status}).`, response.status);
  }
  return response.status === 204 ? void 0 : response.json();
}
async function launch(input, returnTabId) {
  const launchEpoch = reviewEpoch;
  const destination = new URL(input.url);
  if (!["http:", "https:"].includes(destination.protocol) || destination.username || destination.password) {
    throw new Error("Choose an HTTP or HTTPS website.");
  }
  if (origin(input.returnUrl) !== dashboardOrigin) throw new Error("Invalid return address.");
  let auth = input.auth;
  if (!auth) {
    const connection = await getConnection();
    if (!connection) throw new Error("Connect Backline again.");
    auth = { kind: "member", token: connection.token };
  }
  let project;
  let authorName;
  if (auth.kind === "member") {
    const who = await request(auth, "/api/v1/extension-tokens/whoami");
    project = await request(auth, `/api/v1/projects/${input.projectId}`);
    authorName = who.user_email;
  } else {
    const resolved = await request(auth, `/api/v1/review/${encodeURIComponent(auth.shareToken)}`);
    if (resolved.project_id !== input.projectId) throw new Error("This review belongs to another project.");
    const current = await request(auth, "/api/v1/guest-sessions/current");
    if (current.project_id !== input.projectId || current.share_link_id !== resolved.share_link_id) throw new Error("Rejoin this review in Backline first.");
    project = { id: resolved.project_id, name: resolved.project_name, target_origin: resolved.target_origin };
    authorName = auth.displayName;
  }
  if (origin(project.target_origin) !== destination.origin) throw new Error("Open a page on this project's website.");
  const candidates = (await chrome.tabs.query({})).filter((tab2) => {
    try {
      return tab2.id !== returnTabId && !!tab2.url && origin(tab2.url) === destination.origin;
    } catch {
      return false;
    }
  });
  const existing = candidates.find((tab2) => tab2.url === input.url) ?? (destination.origin === dashboardOrigin ? void 0 : candidates[0]);
  const tab = existing ?? await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab.id === void 0) throw new Error("Could not open the review tab.");
  let previous = null;
  const launchId = crypto.randomUUID();
  const waiter = waitForReady(launchId);
  void waiter.ready.catch(() => void 0);
  try {
    await mutateSession(tab.id, (current) => {
      if (launchEpoch !== reviewEpoch) throw new Error("The extension connection changed. Open this review again from Backline.");
      previous = current;
      return {
        project,
        authorName,
        auth,
        member: auth.kind === "member",
        returnUrl: input.returnUrl,
        pageIds: [],
        commentIds: [],
        launchId,
        returnTabId
      };
    });
    if (existing) {
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content-script.js"] });
      const started = await chrome.tabs.sendMessage(tab.id, { type: "native-review-start" });
      if (!started?.ok) throw new Error(started?.error ?? "Reload the website and try Browser review again.");
    } else {
      await chrome.tabs.update(tab.id, { url: destination.href });
    }
    return { ready: await waiter.ready };
  } catch (error) {
    const rolledBack = await mutateSession(tab.id, (latest) => latest?.launchId === launchId ? latest.accessEnded || launchEpoch !== reviewEpoch ? null : previous : void 0);
    if (rolledBack) {
      await chrome.tabs.sendMessage(tab.id, { type: "native-review-stop" }).catch(() => void 0);
    }
    throw error;
  } finally {
    waiter.cancel();
  }
}
async function sessionFor(sender) {
  const tabId = sender.tab?.id;
  if (tabId === void 0 || sender.frameId !== 0 || !sender.url) throw new Error("Open a website review first.");
  const session = await read(tabId);
  if (!session || origin(sender.url) !== origin(session.project.target_origin)) throw new Error("No review on this page.");
  return { session, tabId };
}
async function currentReviewProject(session) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12e3);
  try {
    if (session.auth.kind === "member") {
      const project = await request(session.auth, `/api/v1/projects/${session.project.id}`, { signal: controller.signal });
      if (project.archived_at || project.project_type !== "website" || origin(project.target_origin) !== origin(session.project.target_origin)) {
        throw new NativeReviewError("This project is no longer available for this website review.", 403);
      }
      return { id: project.id, name: project.name, target_origin: project.target_origin, my_role: project.my_role };
    }
    const current = await request(session.auth, "/api/v1/guest-sessions/current", { signal: controller.signal });
    const resolved = await request(session.auth, `/api/v1/review/${encodeURIComponent(session.auth.shareToken)}`, { signal: controller.signal });
    if (current.project_id !== session.project.id || resolved.project_id !== session.project.id || resolved.share_link_id !== current.share_link_id || origin(resolved.target_origin) !== origin(session.project.target_origin)) {
      throw new NativeReviewError("Rejoin the project in Backline.", 403);
    }
    return { id: resolved.project_id, name: resolved.project_name, target_origin: resolved.target_origin };
  } finally {
    clearTimeout(timer);
  }
}
async function endStoredReview(session, tabId) {
  await mutateSession(tabId, (latest) => {
    if (latest?.launchId !== session.launchId) return void 0;
    latest.accessEnded = true;
    latest.auth = { kind: "member", token: "" };
    latest.authorName = "";
    latest.project = { ...latest.project, name: "" };
    latest.pageIds = [];
    latest.commentIds = [];
    return latest;
  });
}
async function validateReviewAccess(session, tabId) {
  try {
    return await currentReviewProject(session);
  } catch (error) {
    if (error instanceof NativeReviewError && [401, 403, 404, 409].includes(error.status)) await endStoredReview(session, tabId);
    throw error;
  }
}
async function handle(message, sender) {
  if (message.type === "native-review-status" || message.type === "native-review-launch") {
    if (sender.frameId !== 0 || !sender.url || origin(sender.url) !== dashboardOrigin) throw new Error("Open Backline to start a review.");
    if (message.type === "native-review-launch") return launch(message.input, sender.tab?.id);
    const connection = await getConnection();
    return {
      version: 2,
      apiBaseUrl: API_BASE_URL,
      extensionVersion: chrome.runtime.getManifest().version,
      workspaceId: connection?.workspaceId ?? null,
      userId: connection?.userId ?? null
    };
  }
  if (message.type === "native-review-info") {
    try {
      const { session: session2 } = await sessionFor(sender);
      if (session2.accessEnded) return null;
      const { project, authorName, member, returnUrl, launchId } = session2;
      return { project, authorName, member, returnUrl, launchId };
    } catch {
      return null;
    }
  }
  const { session, tabId } = await sessionFor(sender);
  if (message.type === "native-review-return") {
    const tabs = (await chrome.tabs.query({})).filter((tab) => tab.id !== tabId);
    const returnPage = new URL(session.returnUrl);
    const original = tabs.find((tab) => {
      if (tab.id !== session.returnTabId || !tab.url) return false;
      try {
        const current = new URL(tab.url);
        return current.origin === returnPage.origin && current.pathname === returnPage.pathname;
      } catch {
        return false;
      }
    });
    const target = original ?? tabs.find((tab) => tab.url === session.returnUrl);
    if (target?.id !== void 0) {
      await chrome.tabs.update(target.id, { active: true });
      await chrome.windows.update(target.windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: session.returnUrl, active: true });
    }
    return;
  }
  if (message.type === "native-review-ready") {
    if (session.accessEnded) throw new NativeReviewError("Review access ended. Return to Backline.", 403);
    if (message.launchId !== session.launchId) throw new Error("This review was replaced. Open it again from Backline.");
    await validateReviewAccess(session, tabId);
    readyWaiters.get(session.launchId)?.();
    return;
  }
  if (message.type === "native-review-check-access") {
    if (session.accessEnded) throw new NativeReviewError("Review access ended. Return to Backline.", 403);
    const project = await validateReviewAccess(session, tabId);
    await mutateSession(tabId, (latest) => {
      if (!latest || latest.launchId !== session.launchId) throw new Error("This review was replaced. Open it again from Backline.");
      if (latest.accessEnded) throw new NativeReviewError("Review access ended. Return to Backline.", 403);
      latest.project = { ...latest.project, ...project };
      return latest;
    });
    readyWaiters.get(session.launchId)?.();
    return { launchId: session.launchId, project };
  }
  if (message.type === "native-review-end") {
    if (message.launchId !== session.launchId) throw new Error("This review was replaced. Return to Backline to reopen it.");
    await mutateSession(tabId, (latest) => latest?.launchId === session.launchId ? null : void 0);
    return;
  }
  if (session.accessEnded) throw new NativeReviewError("Review access ended. Return to Backline.", 403);
  if (message.type === "native-review-capture") {
    const generation = activationGeneration;
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active || tab.url !== message.url) throw new Error("Keep this page visible while capturing.");
    const data = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 85 });
    const after = await chrome.tabs.get(tabId);
    if (generation !== activationGeneration || !after.active || after.url !== message.url) throw new Error("The page changed during capture. Please retry.");
    return data;
  }
  if (message.type === "native-review-diagnostics") {
    await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, world: "MAIN", files: ["main-world.js"] });
    return;
  }
  if (message.type === "native-review-upload") {
    const data = message.file;
    if (!data.data.startsWith("data:") || data.data.length > 28e6) throw new Error("Attachment is too large.");
    const file = await (await fetch(data.data)).blob();
    const form = new FormData();
    form.append("project_id", session.project.id);
    form.append("file", file, data.name);
    return request(session.auth, "/api/v1/uploads/direct", { method: "POST", body: form });
  }
  if (message.type === "native-review-api") {
    const path = String(message.path);
    const method = String(message.method ?? "GET");
    const body = message.body ? JSON.parse(String(message.body)) : null;
    const pageMatch = /^\/api\/v1\/pages\/([a-f0-9]{24})\/comments$/.exec(path);
    const snapshotMatch = /^\/api\/v1\/pages\/([a-f0-9]{24})\/snapshots$/.exec(path);
    const commentMatch = /^\/api\/v1\/comments\/([a-f0-9]{24})$/.exec(path);
    const replyMatch = /^\/api\/v1\/comments\/([a-f0-9]{24})\/replies$/.exec(path);
    const register = path === "/api/v1/pages" && method === "POST" && body?.project_id === session.project.id && typeof body.url === "string" && origin(body.url) === origin(session.project.target_origin);
    const comments = pageMatch && session.pageIds.includes(pageMatch[1]) && ["GET", "POST"].includes(method);
    const update = commentMatch && session.member && session.commentIds.includes(commentMatch[1]) && method === "PATCH";
    const snapshot = snapshotMatch && session.pageIds.includes(snapshotMatch[1]) && method === "POST";
    const reply = replyMatch && session.commentIds.includes(replyMatch[1]) && method === "POST" && typeof body?.body === "string" && body.body.trim().length > 0 && body.body.length <= 1e4 && typeof body.client_request_id === "string" && body.client_request_id.length > 0 && body.client_request_id.length <= 100 && ["body", "layer", "client_request_id"].every((field) => Object.prototype.hasOwnProperty.call(body, field)) && Object.keys(body).every((field) => ["body", "layer", "client_request_id"].includes(field)) && ["client", "team"].includes(body.layer) && (session.member || body.layer === "client");
    if (!register && !comments && !update && !snapshot && !reply) throw new Error("Request is outside this review.");
    const requestController = reply || comments && method === "GET" ? new AbortController() : null;
    const requestTimer = requestController ? setTimeout(() => requestController.abort(), 3e4) : null;
    let result;
    try {
      result = await request(session.auth, path, {
        method,
        ...body ? { body: JSON.stringify(body) } : {},
        ...requestController ? { signal: requestController.signal } : {}
      });
    } catch (error) {
      if (comments && method === "GET" && error instanceof NativeReviewError && [401, 403, 404, 409].includes(error.status)) {
        await endStoredReview(session, tabId);
      }
      throw error;
    } finally {
      if (requestTimer) clearTimeout(requestTimer);
    }
    await mutateSession(tabId, (latest) => {
      if (!latest || latest.accessEnded || latest.launchId !== session.launchId || latest.auth.token !== session.auth.token) return void 0;
      if (register && !Array.isArray(result)) latest.pageIds = [.../* @__PURE__ */ new Set([...latest.pageIds, String(result.id)])];
      if (comments || reply) latest.commentIds = [.../* @__PURE__ */ new Set([...latest.commentIds, ...(Array.isArray(result) ? result : [result]).map((c) => String(c.id))])];
      return latest;
    });
    return result;
  }
  throw new Error("Unknown review action.");
}
function registerNativeReview() {
  chrome.tabs.onActivated.addListener(() => {
    activationGeneration += 1;
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (typeof message?.type !== "string" || !message.type.startsWith("native-review-")) return false;
    void handle(message, sender).then((data) => respond({ ok: true, data }), (error) => respond({ ok: false, error: error instanceof Error ? error.message : "Review failed.", status: error instanceof NativeReviewError ? error.status : 0 }));
    return true;
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void mutateSession(tabId, () => null);
  });
}
async function clearNativeReviews() {
  reviewEpoch += 1;
  const entries = await chrome.storage.session.get(null);
  const keys = Object.keys(entries).filter((name) => name.startsWith("review:"));
  await Promise.all(keys.map((name) => mutateSession(Number(name.slice(7)), () => null)));
  await Promise.all(keys.map((name) => chrome.tabs.sendMessage(Number(name.slice(7)), { type: "native-review-stop" }).catch(() => void 0)));
}

// src/background.ts
registerNativeReview();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "get-connection") {
    getConnection().then((connection) => sendResponse({ connection }));
    return true;
  }
  if (message.type === "set-connection") {
    setConnection(message.connection).then(
      () => sendResponse({ connection: message.connection })
    );
    return true;
  }
  if (message.type === "clear-connection") {
    Promise.all([clearConnection(), clearNativeReviews()]).then(
      () => sendResponse({ connection: null })
    );
    return true;
  }
  return false;
});
