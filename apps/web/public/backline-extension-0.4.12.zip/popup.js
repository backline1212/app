"use strict";
(() => {
  // src/lib/config.ts
  var API_BASE_URL = "https://backlinewidget-production.up.railway.app";
  var DASHBOARD_BASE_URL = "https://backline-qa.vercel.app";

  // src/lib/api.ts
  var ExtensionApiError = class extends Error {
    constructor(status, code, message) {
      super(message);
      this.status = status;
      this.code = code;
    }
  };
  async function apiRequest(path, token, init2 = {}) {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...init2,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        ...init2.headers
      }
    });
    if (!response.ok) {
      if (response.status === 404 && response.headers.get("x-railway-fallback") === "true") {
        throw new ExtensionApiError(503, "SERVICE_UNAVAILABLE", "Backline is temporarily unavailable. Try again shortly.");
      }
      const body = await response.json().catch(() => null);
      throw new ExtensionApiError(
        response.status,
        body?.error?.code ?? "UNKNOWN_ERROR",
        body?.error?.message ?? response.statusText
      );
    }
    if (response.status === 204) {
      return void 0;
    }
    return response.json();
  }

  // src/popup.ts
  function sendMessage(message) {
    return chrome.runtime.sendMessage(message);
  }
  function el(id) {
    const found = document.getElementById(id);
    if (!found) throw new Error(`Missing #${id} in popup.html`);
    return found;
  }
  var disconnectedView = el("disconnected-view");
  var connectedView = el("connected-view");
  var connectForm = el("connect-form");
  var tokenInput = el("token-input");
  var statusEl = el("status");
  var getTokenLink = el("get-token-link");
  var connectedEmail = el("connected-email");
  var connectedWorkspace = el("connected-workspace");
  var disconnectBtn = el("disconnect-btn");
  var activatePointBtn = el("activate-point-btn");
  var activateRegionBtn = el("activate-region-btn");
  var activateStatus = el("activate-status");
  var activityList = el("activity-list");
  var activityEmpty = el("activity-empty");
  var openDashboardBtn = el("open-dashboard-btn");
  function setStatus(message) {
    statusEl.textContent = message;
  }
  async function getCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url || tab.id === void 0) return null;
    try {
      return { id: tab.id, origin: new URL(tab.url).origin };
    } catch {
      return null;
    }
  }
  function renderActivity(comments) {
    activityList.innerHTML = "";
    const topLevel = comments.filter((c) => c.parent_id === null).sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 5);
    if (topLevel.length === 0) {
      activityEmpty.textContent = "No comments on this site yet.";
      return;
    }
    activityEmpty.textContent = "";
    for (const comment of topLevel) {
      const item = document.createElement("li");
      const author = document.createElement("div");
      author.className = "activity-author";
      author.textContent = comment.author_name;
      const body = document.createElement("div");
      body.className = "activity-body";
      body.textContent = comment.body;
      item.append(author, body);
      activityList.append(item);
    }
  }
  async function loadActivity(connection) {
    activityEmpty.textContent = "Loading...";
    activityList.innerHTML = "";
    let dashboardPath = `/w/${connection.workspaceSlug}`;
    try {
      const tab = await getCurrentTab();
      const projects = await apiRequest(
        `/api/v1/workspaces/${connection.workspaceId}/projects`,
        connection.token
      );
      const project = tab ? projects.find((p) => p.target_origin === tab.origin) : void 0;
      if (!project) {
        activityEmpty.textContent = tab ? "No project yet for this site - click Add comment or Draw region to create one." : "Open a regular webpage to see its Backline activity.";
      } else {
        dashboardPath = `/w/${connection.workspaceSlug}/p/${project.id}/board`;
        const comments = await apiRequest(
          `/api/v1/projects/${project.id}/comments`,
          connection.token
        );
        renderActivity(comments);
      }
    } catch (err) {
      activityEmpty.textContent = err instanceof ExtensionApiError ? err.message : "Could not load activity.";
    }
    openDashboardBtn.onclick = () => {
      chrome.tabs.create({ url: `${DASHBOARD_BASE_URL}${dashboardPath}` });
    };
  }
  function renderConnected(connection) {
    connectedEmail.textContent = connection.userEmail;
    connectedWorkspace.textContent = connection.workspaceName;
    connectedView.style.display = "block";
    disconnectedView.style.display = "none";
    void loadActivity(connection);
  }
  function renderDisconnected() {
    connectedView.style.display = "none";
    disconnectedView.style.display = "block";
    setStatus("");
    tokenInput.value = "";
  }
  async function handleConnectSubmit(event) {
    event.preventDefault();
    const token = tokenInput.value.trim();
    if (!token) return;
    setStatus("Connecting...");
    try {
      const whoami = await apiRequest(
        "/api/v1/extension-tokens/whoami",
        token
      );
      const connection = {
        token,
        userId: whoami.user_id,
        userEmail: whoami.user_email,
        workspaceId: whoami.workspace.id,
        workspaceName: whoami.workspace.name,
        workspaceSlug: whoami.workspace.slug
      };
      await sendMessage({ type: "set-connection", connection });
      renderConnected(connection);
    } catch (err) {
      setStatus(
        err instanceof ExtensionApiError ? err.message : "Could not connect. Check the token and try again."
      );
    }
  }
  async function handleDisconnect() {
    await sendMessage({ type: "clear-connection" });
    renderDisconnected();
  }
  async function handleActivate(mode) {
    activateStatus.textContent = "";
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      activateStatus.textContent = "Could not find the current tab.";
      return;
    }
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "activate-annotation", mode });
      window.close();
    } catch {
      activateStatus.textContent = "Backline can't run on this page.";
    }
  }
  connectForm.addEventListener("submit", (event) => void handleConnectSubmit(event));
  disconnectBtn.addEventListener("click", () => void handleDisconnect());
  activatePointBtn.addEventListener("click", () => void handleActivate("point"));
  activateRegionBtn.addEventListener("click", () => void handleActivate("region"));
  getTokenLink.addEventListener("click", () => {
    chrome.tabs.create({ url: DASHBOARD_BASE_URL });
  });
  async function init() {
    const { connection } = await sendMessage({ type: "get-connection" });
    if (connection) {
      renderConnected(connection);
    } else {
      renderDisconnected();
    }
  }
  void init();
})();
