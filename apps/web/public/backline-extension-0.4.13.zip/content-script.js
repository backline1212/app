"use strict";
(() => {
  // ../widget/src/api-client.ts
  var DEFAULT_API_BASE_URL = "http://localhost:8000";
  var WidgetApiError = class extends Error {
    constructor(status, code, message) {
      super(message);
      this.status = status;
      this.code = code;
    }
  };
  function nativeFetch(input, init) {
    const original = window.__backlineNativeFetch;
    return original ? original.call(window, input, init) : fetch(input, init);
  }
  function createApiClient(apiBaseUrl = DEFAULT_API_BASE_URL, getAuthHeader = () => ({}), onUnauthorized = () => void 0) {
    const lifetime = new AbortController();
    function requireOpen() {
      if (lifetime.signal.aborted) throw new WidgetApiError(401, "SESSION_ENDED", "Your review session ended. Rejoin to continue.");
    }
    async function request(path, init = {}) {
      requireOpen();
      const auth = getAuthHeader();
      const response = await nativeFetch(`${apiBaseUrl}${path}`, {
        ...init,
        signal: init.signal ?? lifetime.signal,
        headers: {
          "Content-Type": "application/json",
          ...auth,
          ...init.headers
        }
      });
      requireOpen();
      if (!response.ok) {
        if (response.status === 404 && response.headers.get("x-railway-fallback") === "true") {
          throw new WidgetApiError(503, "SERVICE_UNAVAILABLE", "Backline is temporarily unavailable. Keep this review open and try again shortly.");
        }
        const body2 = await response.json().catch(() => null);
        if (response.status === 401 && auth["X-Guest-Session"]) onUnauthorized();
        throw new WidgetApiError(
          response.status,
          body2?.error?.code ?? "UNKNOWN_ERROR",
          body2?.error?.message ?? response.statusText
        );
      }
      if (response.status === 204) {
        return void 0;
      }
      const body = await response.json();
      requireOpen();
      return body;
    }
    async function upload(path, form) {
      requireOpen();
      const auth = getAuthHeader();
      const response = await nativeFetch(`${apiBaseUrl}${path}`, {
        method: "POST",
        body: form,
        headers: auth,
        signal: lifetime.signal
      });
      requireOpen();
      if (!response.ok) {
        if (response.status === 404 && response.headers.get("x-railway-fallback") === "true") {
          throw new WidgetApiError(503, "SERVICE_UNAVAILABLE", "Backline is temporarily unavailable. Keep this review open and try again shortly.");
        }
        const body2 = await response.json().catch(() => null);
        if (response.status === 401 && auth["X-Guest-Session"]) onUnauthorized();
        throw new WidgetApiError(
          response.status,
          body2?.error?.code ?? "UNKNOWN_ERROR",
          body2?.error?.message ?? response.statusText
        );
      }
      const body = await response.json();
      requireOpen();
      return body;
    }
    return { request, upload, close: () => lifetime.abort() };
  }

  // ../widget/src/comment-submission.ts
  function createCommentSubmission(api, pageId, pageUrl = location.href) {
    const requestId = crypto.randomUUID();
    let serialized = null;
    let ambiguous = false;
    let saved = null;
    let pending = null;
    function requireOriginalPage() {
      if (location.href !== pageUrl) {
        throw new Error("The page changed. Copy your text, then close this draft and comment on the new page.");
      }
    }
    async function send(prepare) {
      if (saved) return saved;
      requireOriginalPage();
      if (serialized === null) {
        const payload = await prepare();
        requireOriginalPage();
        serialized = JSON.stringify({ ...payload, client_request_id: requestId });
      }
      try {
        saved = await api.request(`/api/v1/pages/${pageId}/comments`, {
          method: "POST",
          body: serialized
        });
        return saved;
      } catch (error) {
        const status = error instanceof Error && "status" in error ? Number(error.status) : 0;
        if (!ambiguous && [400, 403, 404, 413, 422].includes(status)) serialized = null;
        else ambiguous = true;
        throw error;
      }
    }
    return {
      isPrepared: () => serialized !== null,
      submit(prepare) {
        if (pending) return pending;
        pending = send(prepare).finally(() => {
          pending = null;
        });
        return pending;
      }
    };
  }

  // ../widget/src/thread-reply.ts
  async function postThreadReply(api, topId, request) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3e4);
    try {
      return await api.request(`/api/v1/comments/${topId}/replies`, {
        method: "POST",
        body: JSON.stringify(request),
        signal: controller.signal
      });
    } finally {
      clearTimeout(timer);
    }
  }

  // ../widget/src/ui-styles.ts
  var HOST_STYLES = `
  :host {
    all: initial;
    /* Backline design tokens (apps/web's backline.css), so the overlay reads as the same
       product as the dashboard around it. --bl-ink-4 is the dashboard's AA-contrast
       value, not the prototype's lighter #9A9D99. */
    --bl-ink: #0B0B0B; --bl-ink-2: #3A3D3A; --bl-ink-3: #6B6E6B; --bl-ink-4: #696C68;
    --bl-paper: #F1F2F0; --bl-surface: #FFFFFF; --bl-line: #DDDEDA; --bl-line-soft: #E9EAE6;
    --bl-mint: #69DEB2; --bl-mint-deep: #0A6B4B; --bl-mint-tint: #E3F8EF;
    --bl-sans: "Inter", "Schibsted Grotesk", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    --bl-mono: "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  }
  * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  .bl-tooltip {
    position: fixed; bottom: 24px; right: 24px; z-index: 2147483000;
    background: #14141A; color: #F2F2F5; padding: 10px 14px; border-radius: 8px;
    font-size: 13px; box-shadow: 0 4px 16px rgba(0,0,0,0.25); max-width: 220px;
  }
  .bl-name-form {
    position: fixed; z-index: 2147483000; background: #FFFFFF; color: #14141A;
    border-radius: 10px; box-shadow: 0 8px 30px rgba(0,0,0,0.25); padding: 16px;
    width: 260px; border: 1px solid rgba(0,0,0,0.08);
    top: 50%; left: 50%; transform: translate(-50%, -50%);
  }
  .bl-name-form input {
    width: 100%; border: 1px solid rgba(0,0,0,0.15); border-radius: 6px; padding: 8px;
    font-size: 13px; margin-top: 6px; margin-bottom: 10px;
  }
  .bl-name-form button {
    background: #4F46E5; color: #fff; border: none; border-radius: 6px; padding: 8px 12px;
    font-size: 13px; cursor: pointer; width: 100%;
  }
  .bl-attachments { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
  .bl-attachment-chip {
    display: flex; align-items: center; gap: 5px; background: #F5F5F7; border-radius: 6px;
    padding: 4px 6px 4px 8px; font-size: 12px; max-width: 100%; border: 1px solid rgba(0,0,0,0.06);
  }
  .bl-attachment-chip.bl-attachment-pending { opacity: 0.6; }
  .bl-attachment-chip.bl-attachment-failed { border-color: #B42318; }
  .bl-attachment-failure { color: #B42318; font-size: 11px; }
  button.bl-attachment-retry {
    background: none; border: none; color: #2455A4; cursor: pointer;
    padding: 0 2px; font-size: 11px; font-weight: 700; flex-shrink: 0;
  }
  .bl-attachment-name {
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;
  }
  .bl-pin {
    /* absolute (document coordinates): must scroll with the page to stay attached to
       the element it marks, the same reasoning as .bl-card below. The square
       bottom-left corner is the pin's point, lifted by its own height so that corner
       sits exactly on the clicked spot. */
    position: absolute; width: 24px; height: 24px; border-radius: 50% 50% 50% 3px;
    background: var(--bl-ink); color: #fff; border: 2px solid #fff;
    transform: translateY(-100%); display: grid; place-items: center;
    font-size: 13px; font-weight: 700; line-height: 1;
    z-index: 2147482999; box-shadow: 0 2px 5px rgba(11,11,11,0.22); cursor: pointer;
  }
  /* A resolved or won't-fix comment keeps its pin, quieter, so what is still open
     stands out. */
  .bl-pin.bl-pin-closed { background: #FFFFFF; color: var(--bl-ink-3); border-color: var(--bl-line); opacity: 0.8; }
  .bl-pin.bl-pin-closed:hover, .bl-pin.bl-pin-closed.bl-pin-active { opacity: 1; }
  /* The pin whose card is open. */
  .bl-pin.bl-pin-active { box-shadow: 0 0 0 3px var(--bl-mint), 0 2px 5px rgba(11,11,11,0.22); z-index: 2147483000; }
  /* A drawn-region comment's area, following the element it was drawn on. */
  .bl-region {
    position: absolute; z-index: 2147482998; pointer-events: none;
    border: 2px solid var(--bl-mint-deep); background: rgba(105, 222, 178, 0.14); border-radius: 2px;
  }
  .bl-region.bl-region-draft { border-style: dashed; }
  .bl-region.bl-region-closed { border-color: var(--bl-ink-4); background: rgba(105, 110, 104, 0.06); border-style: dotted; }
  .bl-region.bl-region-active { background: rgba(105, 222, 178, 0.24); }
  /* Browse mode shows the site alone - no pins, regions, threads or composer. */
  :host([data-mode="browse"]) .bl-pin,
  :host([data-mode="browse"]) .bl-region,
  :host([data-mode="browse"]) .bl-card { display: none !important; }
  /* A click elsewhere while a comment is half-written points back at it. */
  @keyframes bl-nudge {
    0%, 100% { transform: translateX(0); }
    20% { transform: translateX(-6px); }
    40% { transform: translateX(6px); }
    60% { transform: translateX(-4px); }
    80% { transform: translateX(3px); }
  }
  .bl-card.bl-nudge { animation: bl-nudge 0.36s ease; box-shadow: 0 0 0 3px var(--bl-mint), 0 20px 48px rgba(11,11,11,0.24); }
  @media (prefers-reduced-motion: reduce) { .bl-card.bl-nudge { animation: none; } }
  /* The pin for a comment still being written - the design's "ghost" pin. */
  .bl-pin.bl-pin-ghost {
    background: var(--bl-mint); color: var(--bl-ink);
    outline: 2px dashed var(--bl-ink); outline-offset: 2px;
  }
  .bl-pin.bl-pin-ghost::after { content: "+"; }
  .bl-pin:focus-visible { outline: 3px solid #14141A; outline-offset: 3px; }
  .bl-status { font-size: 12px; color: #6B6B76; margin-top: 8px; }
  .bl-toast {
    position: fixed; bottom: 24px; left: 24px; z-index: 2147483000;
    background: #14141A; color: #F2F2F5; padding: 10px 14px; border-radius: 8px;
    font-size: 13px; box-shadow: 0 4px 16px rgba(0,0,0,0.25); max-width: 240px;
  }
  .bl-toast-offline { background: #8A5B00; color: #FFFFFF; }
  /* In the dashboard's canvas its quick-tools dock floats over the bottom of the frame. */
  :host([data-embedded]) .bl-tooltip, :host([data-embedded]) .bl-toast { bottom: 88px; }
  button.bl-attachment-remove {
    background: none; border: none; color: #6B6B76; cursor: pointer; width: auto;
    padding: 0 2px; font-size: 14px; line-height: 1; flex-shrink: 0;
  }
  button.bl-attachment-remove:hover { color: #EF4444; }

  /* ---- Comment cards: the new-comment composer and the read-only view of an
     existing comment share this box (the design's composer-pop) ---- */
  .bl-card {
    /* absolute (document coordinates), not fixed (viewport coordinates): the card
       opens at the point the reviewer clicked, on an already-scrolled page - fixed
       positioning would leave it glued to that screen position as the page scrolls
       underneath it, drifting away from the element it's actually about. */
    position: absolute; z-index: 2147483000; width: 344px; max-width: calc(100vw - 24px);
    display: flex; flex-direction: column;
    background: var(--bl-surface); color: var(--bl-ink); border: 1px solid var(--bl-line);
    border-radius: 8px; box-shadow: 0 20px 48px rgba(11,11,11,0.24);
    font-size: 14px; line-height: 1.45; text-align: left;
  }
  .bl-card, .bl-card * { font-family: var(--bl-sans); }
  .bl-card .bl-cp-av, .bl-card .bl-cp-loc, .bl-card .bl-cp-lbl,
  .bl-card .bl-cp-ctx, .bl-card .bl-cp-hint, .bl-card .bl-cp-hint kbd {
    font-family: var(--bl-mono);
  }
  .bl-card button { font: inherit; margin: 0; cursor: pointer; }
  .bl-card button:disabled { cursor: default; opacity: 0.55; }
  .bl-cp-head {
    display: flex; flex: none; align-items: center; gap: 9px; padding: 11px 12px;
    background: var(--bl-ink); color: #fff; border-radius: 7px 7px 0 0;
    font-size: 13px; font-weight: 600;
  }
  .bl-card .bl-cp-av {
    width: 22px; height: 22px; border-radius: 50%; background: var(--bl-mint);
    color: var(--bl-ink); display: grid; place-items: center; flex: none;
    font-size: 9px; font-weight: 700;
  }
  .bl-cp-title { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .bl-card .bl-cp-loc {
    margin-left: auto; min-width: 0; overflow: hidden; text-overflow: ellipsis;
    white-space: nowrap; color: rgba(255,255,255,0.72); background: rgba(255,255,255,0.12);
    border-radius: 20px; padding: 2px 8px; font-size: 10px; font-weight: 400;
  }
  .bl-card button.bl-cancel {
    flex: none; background: none; border: 0; padding: 0 2px; color: rgba(255,255,255,0.7);
    font-size: 18px; line-height: 1;
  }
  .bl-card button.bl-cancel:hover { color: #fff; }
  /* The comment's status, in the header of the read-only comment view
     (ui-comment-view.ts): a button with a menu where this viewer can change it, a plain
     pill where they can't. */
  .bl-cv-status-wrap { position: relative; flex: none; }
  .bl-card .bl-cv-status {
    display: inline-flex; align-items: center; gap: 6px; flex: none; height: 22px;
    padding: 0 8px; border: 0; border-radius: 20px; background: rgba(255,255,255,0.12);
    color: #fff; font-size: 11px; font-weight: 500; line-height: 1; white-space: nowrap;
  }
  .bl-card button.bl-cv-status { padding-right: 6px; }
  .bl-card button.bl-cv-status:hover, .bl-card button.bl-cv-status[aria-expanded="true"] {
    background: rgba(255,255,255,0.22);
  }
  .bl-card button.bl-cv-status:focus-visible { outline: 2px solid var(--bl-mint); outline-offset: 2px; }
  .bl-card button.bl-cv-status[aria-busy="true"] { opacity: 0.6; cursor: progress; }
  .bl-cv-status svg { color: rgba(255,255,255,0.7); flex: none; }
  .bl-cv-status-dot { width: 7px; height: 7px; border-radius: 50%; flex: none; }
  .bl-cv-status-menu {
    position: absolute; top: calc(100% + 6px); right: 0; z-index: 1;
    display: grid; gap: 1px; min-width: 168px; padding: 4px;
    background: var(--bl-surface); color: var(--bl-ink); border: 1px solid var(--bl-line);
    border-radius: 6px; box-shadow: 0 12px 32px rgba(11,11,11,0.18);
  }
  .bl-cv-status-menu.bl-is-up { top: auto; bottom: calc(100% + 6px); }
  .bl-cv-status-menu[hidden] { display: none; }
  .bl-card .bl-cv-status-opt {
    display: flex; align-items: center; gap: 8px; width: 100%; padding: 7px 8px;
    border: 0; border-radius: 4px; background: none; color: var(--bl-ink-2);
    font-size: 12.5px; font-weight: 500; line-height: 1.2; text-align: left;
  }
  .bl-card .bl-cv-status-opt:hover, .bl-card .bl-cv-status-opt:focus-visible {
    background: var(--bl-paper); color: var(--bl-ink); outline: none;
  }
  .bl-cv-status-opt svg { margin-left: auto; color: var(--bl-mint-deep); flex: none; visibility: hidden; }
  .bl-card .bl-cv-status-opt[aria-checked="true"] { color: var(--bl-ink); font-weight: 600; }
  .bl-cv-status-opt[aria-checked="true"] svg { visibility: visible; }
  .bl-cp-body { min-height: 0; overflow-y: auto; padding: 13px 13px 12px; }
  /* max-height is the cap the composer's own auto-grow reads back out of the computed
     style (ui-composer.ts) - one source of truth for how tall this can get before it
     starts scrolling instead. resize stays on, so it's still draggable past that. */
  .bl-card textarea {
    display: block; width: 100%; min-height: 78px; max-height: 40vh; margin: 0;
    padding: 10px 11px; overflow-y: auto;
    border: 1px solid var(--bl-line); border-radius: 3px; background: var(--bl-surface);
    color: var(--bl-ink); font-size: 13.5px; line-height: 1.5; resize: vertical; outline: none;
  }
  .bl-card textarea:focus { border-color: var(--bl-ink); }
  .bl-card textarea::placeholder { color: var(--bl-ink-4); }
  .bl-cp-sec { margin-top: 12px; }
  .bl-card .bl-cp-lbl {
    display: block; margin-bottom: 7px; font-size: 9px; letter-spacing: 0.07em;
    color: var(--bl-ink-4);
  }
  .bl-cp-tags { display: flex; flex-wrap: wrap; gap: 6px; }
  .bl-card .bl-cp-tag {
    display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 11px 0 9px;
    border: 1px solid var(--bl-line); border-radius: 20px; background: var(--bl-surface);
    color: var(--bl-ink-2); font-size: 12px; font-weight: 500;
  }
  .bl-cp-tag svg { color: var(--bl-ink-4); flex: none; }
  .bl-card button.bl-cp-tag:hover { border-color: var(--bl-ink-4); }
  .bl-card .bl-cp-tag[aria-pressed="true"], .bl-card .bl-cp-tag.bl-is-on {
    background: var(--bl-ink); border-color: var(--bl-ink); color: #fff;
  }
  .bl-cp-tag[aria-pressed="true"] svg, .bl-cp-tag.bl-is-on svg { color: var(--bl-mint); }
  .bl-cp-shots { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-top: 12px; }
  /* The uploaded-file chips flow in the same row as the attach button. */
  .bl-cp-shots .bl-attachments { display: contents; }
  .bl-card .bl-attachment-chip {
    height: 34px; border-radius: 3px; border: 1px solid var(--bl-line);
    background: var(--bl-paper); color: var(--bl-ink-2);
  }
  .bl-card button.bl-cp-attach {
    display: inline-flex; align-items: center; gap: 7px; width: auto; height: 34px;
    padding: 0 12px; border: 1px dashed var(--bl-line); border-radius: 3px;
    background: var(--bl-surface); color: var(--bl-ink-3); font-size: 12.5px;
  }
  .bl-card button.bl-cp-attach svg { color: var(--bl-ink-4); }
  .bl-card button.bl-cp-attach:hover { border-color: var(--bl-ink); border-style: solid; color: var(--bl-ink); }
  .bl-card button.bl-cp-attach:hover svg { color: var(--bl-ink); }
  .bl-card .bl-cp-ctx {
    display: flex; align-items: center; flex-wrap: wrap; gap: 7px; margin-top: 12px;
    padding: 8px 10px; background: var(--bl-paper); border-radius: 3px;
    font-size: 10px; color: var(--bl-ink-3);
  }
  .bl-cp-ctx svg { color: var(--bl-ink-4); flex: none; }
  .bl-cp-sep { width: 1px; height: 10px; background: var(--bl-line); flex: none; }
  .bl-cp-rgn {
    display: inline-flex; align-items: center; gap: 5px; margin-left: auto;
    color: var(--bl-mint-deep); background: var(--bl-mint-tint); border-radius: 20px; padding: 2px 8px;
  }
  .bl-cp-rgn svg { color: var(--bl-mint-deep); }
  .bl-card .bl-status { margin-top: 10px; font-size: 12px; color: var(--bl-ink-3); }
  .bl-card .bl-status:empty { display: none; }
  .bl-card button.bl-copy-draft {
    margin-top: 8px; padding: 4px 0; background: none; border: 0;
    color: var(--bl-ink); font-size: 12px; text-decoration: underline;
  }
  .bl-card button.bl-copy-draft[hidden] { display: none; }
  .bl-cp-foot {
    display: flex; align-items: center; gap: 8px; margin-top: 13px; padding-top: 12px;
    border-top: 1px solid var(--bl-line-soft);
  }
  .bl-card .bl-cp-hint { margin-right: auto; font-size: 9.5px; color: var(--bl-ink-4); white-space: nowrap; }
  .bl-card .bl-cp-hint kbd {
    background: var(--bl-paper); border: 1px solid var(--bl-line); border-radius: 3px;
    padding: 1px 5px; font-size: inherit; font-weight: 500; color: var(--bl-ink-3);
  }
  .bl-card button.bl-cp-cancel {
    background: none; border: 0; border-radius: 3px; padding: 8px 12px;
    font-size: 12.5px; color: var(--bl-ink-3);
  }
  .bl-card button.bl-cp-cancel:hover:not(:disabled) { background: var(--bl-paper); color: var(--bl-ink); }
  .bl-card button.bl-submit {
    display: inline-flex; align-items: center; gap: 7px; background: var(--bl-ink); color: #fff;
    border: 0; border-radius: 3px; padding: 8px 14px; font-size: 12.5px; font-weight: 600;
  }
  .bl-card button.bl-submit:hover:not(:disabled) { background: #232523; }
  /* Existing thread and optional reply editor (ui-comment-view.ts). */
  .bl-cv-reply-form { margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--bl-line-soft); }
  .bl-cv-reply-form textarea { display: block; margin-top: 8px; text-transform: none; letter-spacing: normal; }
  .bl-cv-visibility { margin: 6px 0 0; font-size: 11px; color: var(--bl-ink-3); }
  .bl-reply-discard { font-size: 12px; margin-top: 10px; padding: 8px; border: 1px solid var(--bl-line); }
  .bl-reply-discard[hidden] { display: none; }
  .bl-cv-text {
    margin: 0; font-size: 13.5px; line-height: 1.5; color: var(--bl-ink);
    white-space: pre-wrap; word-break: break-word;
  }
  .bl-cv-files { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-top: 12px; }
  .bl-card .bl-cv-screenshot { margin-top: 12px; }
  .bl-cv-capture-warning { margin: 12px 0 0; font-size: 12px; line-height: 1.45; color: var(--bl-ink-2); }
  .bl-cv-replies {
    display: flex; flex-direction: column; gap: 10px; margin-top: 12px; padding-top: 12px;
    border-top: 1px solid var(--bl-line-soft);
  }
  .bl-cv-reply-head { display: flex; align-items: baseline; gap: 7px; }
  .bl-cv-reply-author { font-size: 12px; font-weight: 600; color: var(--bl-ink); }
  .bl-cv-reply-time { font-size: 10.5px; color: var(--bl-ink-4); }
  .bl-cv-reply-body {
    margin: 3px 0 0; font-size: 12.5px; line-height: 1.5; color: var(--bl-ink-2);
    white-space: pre-wrap; word-break: break-word;
  }
  .bl-card .bl-attachment-link {
    display: inline-flex; align-items: center; gap: 6px; height: 34px; max-width: 100%;
    padding: 0 10px; border: 1px solid var(--bl-line); border-radius: 3px;
    background: var(--bl-paper); color: var(--bl-ink-2); font-size: 12px; text-decoration: none;
  }
  .bl-card .bl-attachment-link:hover { border-color: var(--bl-ink); color: var(--bl-ink); }
  .bl-card .bl-attachment-link.bl-cv-thumb { width: 64px; height: 48px; padding: 0; overflow: hidden; }
  .bl-cv-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
`;
  function createShadowRoot() {
    const host = document.createElement("div");
    host.setAttribute("data-backline-root", "true");
    document.body.appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = HOST_STYLES;
    shadow.appendChild(style);
    for (const type of ["keydown", "keypress", "keyup"]) {
      shadow.addEventListener(type, (event) => event.stopPropagation());
    }
    return shadow;
  }

  // ../widget/src/ui-notifications.ts
  function showTooltip(shadow) {
    const tooltip = document.createElement("div");
    tooltip.className = "bl-tooltip";
    tooltip.textContent = "Tap anywhere on the page to leave feedback.";
    shadow.appendChild(tooltip);
    const timer = setTimeout(() => tooltip.remove(), 6e3);
    return {
      dismiss: () => {
        clearTimeout(timer);
        tooltip.remove();
      }
    };
  }
  function renderPin(shadow, x, y, ticketNumber) {
    const pin = document.createElement("div");
    pin.className = "bl-pin";
    pin.style.left = `${x}px`;
    pin.style.top = `${y}px`;
    if (ticketNumber != null) pin.textContent = String(ticketNumber);
    shadow.appendChild(pin);
    return pin;
  }

  // ../widget/src/ui-attachments.ts
  var ATTACHMENT_ACCEPT = "image/jpeg,image/png,image/webp,image/gif,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/markdown,.md";
  var MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024;
  function attachmentIcon() {
    return `<svg viewBox="0 0 16 16" width="13" height="13" fill="none" aria-hidden="true"><path d="M11.5 5.5 6.8 10.2a2 2 0 1 1-2.8-2.8l5-5a3 3 0 1 1 4.2 4.2l-5.2 5.2a1 1 0 1 1-1.4-1.4L11 5.9" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }
  function setupAttachments(composer, uploadFile, onCountChange, onProblem) {
    const attachmentsEl = composer.querySelector(".bl-attachments");
    const fileInput = composer.querySelector(".bl-attach-input");
    const attachButton = composer.querySelector(".bl-attach-button");
    const uploaded = [];
    let pending = 0;
    let disabled = false;
    const reportCount = () => onCountChange?.(attachmentsEl.children.length);
    function addFiles(files) {
      if (disabled) return;
      for (const file of files) {
        let attemptUpload2 = function() {
          chip.classList.remove("bl-attachment-failed");
          chip.classList.add("bl-attachment-pending");
          retryButton.hidden = true;
          failureLabel.hidden = true;
          pending += 1;
          void uploadFile(file).catch(() => null).then((uploadedResult) => {
            pending -= 1;
            if (removed) return;
            chip.classList.remove("bl-attachment-pending");
            if (!uploadedResult) {
              chip.classList.add("bl-attachment-failed");
              retryButton.hidden = false;
              failureLabel.hidden = false;
              onProblem?.(`${file.name} couldn't be uploaded. Retry or remove it.`);
              return;
            }
            result = uploadedResult;
            uploaded.push(uploadedResult);
          });
        };
        var attemptUpload = attemptUpload2;
        if (file.size > MAX_ATTACHMENT_BYTES) {
          onProblem?.(`${file.name} is over 10 MB and wasn't attached.`);
          continue;
        }
        const chip = document.createElement("span");
        chip.className = "bl-attachment-chip bl-attachment-pending";
        chip.innerHTML = `${attachmentIcon()}<span class="bl-attachment-name"></span><span class="bl-attachment-failure" hidden>Failed</span><button type="button" class="bl-attachment-retry" hidden>Retry</button><button type="button" class="bl-attachment-remove" aria-label="Remove attachment">&times;</button>`;
        chip.querySelector(".bl-attachment-name").textContent = file.name;
        attachmentsEl.appendChild(chip);
        reportCount();
        const removeButton = chip.querySelector(".bl-attachment-remove");
        const retryButton = chip.querySelector(".bl-attachment-retry");
        const failureLabel = chip.querySelector(".bl-attachment-failure");
        let result = null;
        let removed = false;
        removeButton.addEventListener("click", () => {
          if (disabled) return;
          removed = true;
          chip.remove();
          reportCount();
          if (result) {
            const idx = uploaded.indexOf(result);
            if (idx !== -1) uploaded.splice(idx, 1);
          }
        });
        retryButton.addEventListener("click", () => {
          if (!disabled && !removed) attemptUpload2();
        });
        attemptUpload2();
      }
    }
    attachButton.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      const files = Array.from(fileInput.files ?? []);
      fileInput.value = "";
      addFiles(files);
    });
    return {
      getAttachments: () => uploaded,
      pendingCount: () => pending,
      failedCount: () => attachmentsEl.querySelectorAll(".bl-attachment-failed").length,
      addFiles,
      disable: () => {
        disabled = true;
        attachButton.setAttribute("disabled", "true");
        fileInput.setAttribute("disabled", "true");
        attachmentsEl.querySelectorAll("button").forEach((button) => {
          button.disabled = true;
        });
      },
      enable: () => {
        disabled = false;
        attachButton.removeAttribute("disabled");
        fileInput.removeAttribute("disabled");
        attachmentsEl.querySelectorAll("button").forEach((button) => {
          button.disabled = false;
        });
      },
      reset: () => {
        uploaded.length = 0;
        attachmentsEl.innerHTML = "";
        reportCount();
      }
    };
  }

  // ../widget/src/ui-card.ts
  var svg = (paths, strokeWidth = 1.8, size = 12) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
  var TAG_ICONS = {
    Bug: '<path d="M8 6h8M9 3l1.5 3M15 3l-1.5 3"/><rect x="6" y="6" width="12" height="14" rx="6"/><path d="M3 11h3M18 11h3M3 17h3M18 17h3"/>',
    Copy: '<path d="M4 6h16M4 12h10M4 18h13"/>',
    Design: '<path d="M12 19l7-7 3 3-7 7-3-3zM18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5zM2 2l7.6 7.6"/><circle cx="11" cy="11" r="2"/>',
    Responsive: '<rect x="2" y="4" width="14" height="10" rx="2"/><rect x="16" y="9" width="6" height="11" rx="1.5"/>',
    Content: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h6M7 13h10"/>',
    Accessibility: '<circle cx="12" cy="5" r="1.6"/><path d="M4 9l8 1.5L20 9M12 10.5V15l-3 6M12 15l3 6"/>'
  };
  function escapeHtml(text) {
    return text.replace(/[&<>"']/g, (ch) => `&#${ch.charCodeAt(0)};`);
  }
  function initials(name) {
    const words = name.trim().split(/\s+/).map((word) => word.replace(/[^\p{L}\p{N}]/gu, "")).filter(Boolean);
    if (words.length === 0) return "?";
    const letters = words.length === 1 ? words[0].slice(0, 2) : words[0][0] + words[words.length - 1][0];
    return letters.toUpperCase();
  }
  function cardHeaderHtml(opts) {
    return `
    <div class="bl-cp-head">
      <span class="bl-cp-av" aria-hidden="true">${escapeHtml(initials(opts.authorName))}</span>
      <span class="bl-cp-title ${opts.titleClass ?? ""}">${escapeHtml(opts.title)}</span>
      <span class="bl-cp-loc" title="${escapeHtml(opts.pagePath)}">${escapeHtml(opts.pagePath)}</span>
      ${opts.trailingHtml ?? ""}
      <button type="button" class="bl-cancel" aria-label="${escapeHtml(opts.closeLabel)}" title="${escapeHtml(opts.closeLabel)}">&times;</button>
    </div>`;
  }
  var CARD_WIDTH = 344;
  var EDGE_GAP = 12;
  var bottomInset = EDGE_GAP;
  var layoutListeners = /* @__PURE__ */ new Set();
  function setCardBottomInset(px) {
    const next = Math.max(EDGE_GAP, px);
    if (next === bottomInset) return;
    bottomInset = next;
    for (const update of layoutListeners) update();
  }
  function observeCardPlacement(card, x, y) {
    const update = () => {
      if (!card.isConnected) {
        stop();
        return;
      }
      placeCard(card, x, y);
    };
    const observer = new ResizeObserver(update);
    function stop() {
      observer.disconnect();
      window.removeEventListener("resize", update);
      layoutListeners.delete(update);
    }
    observer.observe(card);
    window.addEventListener("resize", update);
    layoutListeners.add(update);
    update();
    return stop;
  }
  function placeCard(card, x, y) {
    const width = Math.min(CARD_WIDTH, window.innerWidth - EDGE_GAP * 2);
    card.style.maxHeight = `${Math.max(1, window.innerHeight - bottomInset - EDGE_GAP)}px`;
    const height = card.offsetHeight;
    const viewRight = window.scrollX + window.innerWidth - EDGE_GAP;
    const viewBottom = window.scrollY + window.innerHeight - bottomInset;
    let left = x + 16;
    if (left + width > viewRight) left = x - width - 16;
    left = Math.max(window.scrollX + EDGE_GAP, Math.min(left, viewRight - width));
    let top = y + 12;
    if (top + height > viewBottom) top = viewBottom - height;
    top = Math.max(window.scrollY + EDGE_GAP, top);
    card.style.left = `${left}px`;
    card.style.top = `${top}px`;
  }

  // ../widget/src/ui-composer.ts
  var COMPOSER_TAGS = ["Bug", "Copy", "Design", "Responsive"];
  var DEVICE_ICONS = {
    Desktop: '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8"/>',
    Tablet: '<rect x="5" y="3" width="14" height="18" rx="2"/>',
    Mobile: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18.5h2"/>'
  };
  var GLOBE_ICON = '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 010 18 15 15 0 010-18"/>';
  var REGION_ICON = '<rect x="3" y="3" width="18" height="18" rx="2"/>';
  var IMAGE_ICON = '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.7"/><path d="M21 15l-5-5L5 20"/>';
  var ARROW_ICON = '<path d="M5 12h14M13 6l6 6-6 6"/>';
  function deviceKind(width) {
    if (width <= 560) return "Mobile";
    if (width <= 1024) return "Tablet";
    return "Desktop";
  }
  var PASTED_IMAGE_EXTENSIONS = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/gif": "gif",
    "image/webp": "webp"
  };
  function pastedImageFiles(clipboardData) {
    if (!clipboardData) return [];
    const files = [];
    Array.from(clipboardData.items).forEach((item, index) => {
      if (!item.type.startsWith("image/")) return;
      const blob = item.getAsFile();
      if (!blob) return;
      const ext = PASTED_IMAGE_EXTENSIONS[item.type] ?? "png";
      const suffix = index > 0 ? `-${index}` : "";
      files.push(new File([blob], `pasted-screenshot-${Date.now()}${suffix}.${ext}`, { type: item.type }));
    });
    return files;
  }
  function autoGrowTextarea(textarea, onResize) {
    let floor = 0;
    let lastSet = "";
    const fit = () => {
      const styles = getComputedStyle(textarea);
      const border = parseFloat(styles.borderTopWidth) + parseFloat(styles.borderBottomWidth);
      textarea.style.height = "auto";
      let next = textarea.scrollHeight + border;
      const max = parseFloat(styles.maxHeight);
      if (Number.isFinite(max)) next = Math.min(next, max);
      textarea.style.height = `${Math.max(next, floor)}px`;
      lastSet = textarea.style.height;
      onResize();
    };
    const observer = new ResizeObserver(() => {
      if (textarea.style.height === lastSet) return;
      floor = textarea.getBoundingClientRect().height;
      lastSet = textarea.style.height;
      onResize();
    });
    observer.observe(textarea);
    textarea.addEventListener("input", fit);
    fit();
    return () => {
      observer.disconnect();
      textarea.removeEventListener("input", fit);
    };
  }
  var activeComposer = null;
  var relatedDrafts = /* @__PURE__ */ new Set();
  function registerRelatedDraft(draft) {
    relatedDrafts.add(draft);
    return () => {
      relatedDrafts.delete(draft);
    };
  }
  function composerHasDraft() {
    return (activeComposer?.hasDraft() ?? false) || [...relatedDrafts].some((draft) => draft.hasDraft());
  }
  function cancelEmptyComposer() {
    if (activeComposer && !activeComposer.hasDraft()) activeComposer.cancel();
  }
  function discardComposerForTeardown() {
    activeComposer?.cancel();
  }
  function nudgeComposer() {
    if (activeComposer?.hasDraft()) activeComposer.nudge();
    else [...relatedDrafts].find((draft) => draft.hasDraft())?.nudge();
  }
  function openComposer(shadow, x, y, onSubmit, onCancel, uploadFile, details) {
    const composer = document.createElement("div");
    composer.className = "bl-card bl-composer";
    composer.setAttribute("role", "dialog");
    composer.setAttribute("aria-label", "New comment");
    const width = window.innerWidth;
    const device = deviceKind(width);
    const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
    composer.innerHTML = `
    ${cardHeaderHtml({
      authorName: details.authorName,
      title: "New comment",
      pagePath: details.pagePath,
      closeLabel: "Cancel comment"
    })}
    <div class="bl-cp-body">
      <textarea placeholder="What needs to change here?" required aria-label="Comment"></textarea>
      <div class="bl-cp-sec">
        <span class="bl-cp-lbl">TAG THIS AS</span>
        <div class="bl-cp-tags" role="group" aria-label="Tag this as">
          ${COMPOSER_TAGS.map(
      (tag, i) => `<button type="button" class="bl-cp-tag" data-tag="${tag}" aria-pressed="${i === 0}">${svg(TAG_ICONS[tag])}${tag}</button>`
    ).join("")}
        </div>
      </div>
      <div class="bl-cp-shots">
        <div class="bl-attachments"></div>
        <button type="button" class="bl-attach-button bl-cp-attach">${svg(IMAGE_ICON, 1.8, 14)}<span class="bl-cp-attach-label">Attach a screenshot</span></button>
        <input type="file" class="bl-attach-input" accept="${ATTACHMENT_ACCEPT}" multiple hidden aria-label="Choose files to attach" />
      </div>
      <div class="bl-cp-ctx">
        ${svg(DEVICE_ICONS[device])}${device}
        <span class="bl-cp-sep" aria-hidden="true"></span>${svg(GLOBE_ICON)}${escapeHtml(details.browser)}
        <span class="bl-cp-sep" aria-hidden="true"></span>${width}px
        ${details.regionSize ? `<span class="bl-cp-rgn">${svg(REGION_ICON, 2)}${escapeHtml(details.regionSize)}</span>` : ""}
      </div>
      <div class="bl-status" role="status" aria-live="polite"></div>
      <button type="button" class="bl-copy-draft" hidden>Copy comment text</button>
      <div class="bl-cp-foot">
        <span class="bl-cp-hint"><kbd>${isMac ? "&#8984;" : "Ctrl"}</kbd> <kbd>&#8629;</kbd> to post</span>
        <button type="button" class="bl-cp-cancel">Cancel</button>
        <button type="button" class="bl-submit">${svg(ARROW_ICON, 2.2)}Post comment</button>
      </div>
    </div>
  `;
    shadow.appendChild(composer);
    const stopPlacement = observeCardPlacement(composer, x, y);
    const statusEl = composer.querySelector(".bl-status");
    const submitButton = composer.querySelector(".bl-submit");
    const closeButton = composer.querySelector(".bl-cancel");
    const cancelButton = composer.querySelector(".bl-cp-cancel");
    const copyButton = composer.querySelector(".bl-copy-draft");
    const attachLabel = composer.querySelector(".bl-cp-attach-label");
    const tagButtons = Array.from(composer.querySelectorAll(".bl-cp-tag"));
    const textarea = composer.querySelector("textarea");
    const attachments = setupAttachments(
      composer,
      uploadFile,
      (count) => {
        attachLabel.textContent = count > 0 ? "Add another" : "Attach a screenshot";
      },
      (message) => {
        statusEl.textContent = message;
      }
    );
    let selectedTag = COMPOSER_TAGS[0];
    let submitted = false;
    let retryLocked = false;
    let posted = false;
    let closeDelay = 1200;
    let closed = false;
    let discardArmedUntil = 0;
    const hasDraft = () => !closed && !posted && (submitted || textarea.value.trim() !== "" || attachments.getAttachments().length > 0 || attachments.pendingCount() > 0 || attachments.failedCount() > 0);
    function nudge() {
      if (closed) return;
      composer.classList.remove("bl-nudge");
      void composer.offsetWidth;
      composer.classList.add("bl-nudge");
      if (!submitted) {
        if (!retryLocked) statusEl.textContent = "Post or cancel this comment first.";
        textarea.focus({ preventScroll: true });
      }
      composer.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
    const handle = { hasDraft, nudge, cancel };
    activeComposer = handle;
    for (const button of tagButtons) {
      button.addEventListener("click", () => {
        selectedTag = button.dataset.tag;
        for (const other of tagButtons) other.setAttribute("aria-pressed", String(other === button));
      });
    }
    function removeOutsideClickListener() {
      document.removeEventListener("click", outsideClickHandler, true);
    }
    function removeComposer() {
      if (closed) return;
      closed = true;
      if (activeComposer === handle) activeComposer = null;
      stopPlacement();
      stopAutoGrow();
      removeOutsideClickListener();
      textarea.value = "";
      composer.remove();
    }
    function cancel() {
      if (closed) return;
      removeComposer();
      if (!submitted) onCancel();
    }
    function setFormDisabled(disabled) {
      composer.setAttribute("aria-busy", String(disabled));
      for (const button of [submitButton, closeButton, cancelButton, copyButton]) {
        if (disabled) button.setAttribute("disabled", "true");
        else button.removeAttribute("disabled");
      }
      textarea.readOnly = disabled || retryLocked;
      for (const button of tagButtons) button.disabled = disabled || retryLocked;
      if (disabled || retryLocked) attachments.disable();
      else attachments.enable();
    }
    function submit() {
      const body = textarea.value.trim();
      if (submitted) return;
      if (!body) {
        statusEl.textContent = "Write a comment before posting.";
        textarea.focus({ preventScroll: true });
        return;
      }
      if (attachments.pendingCount() > 0) {
        statusEl.textContent = "Wait for the attachment to finish uploading.";
        return;
      }
      if (attachments.failedCount() > 0) {
        statusEl.textContent = "Retry or remove failed attachments before posting.";
        return;
      }
      submitted = true;
      discardArmedUntil = 0;
      statusEl.textContent = retryLocked ? "Retrying the original comment..." : "Preparing your comment...";
      setFormDisabled(true);
      void Promise.resolve().then(() => onSubmit({ body, attachments: attachments.getAttachments(), tags: [selectedTag] })).then((ok) => {
        if (closed) return;
        if (ok) {
          posted = true;
          if (activeComposer === handle) activeComposer = null;
          window.setTimeout(removeComposer, closeDelay);
          return;
        }
        submitted = false;
        copyButton.hidden = false;
        setFormDisabled(false);
      }).catch((error) => {
        if (closed) return;
        submitted = false;
        copyButton.hidden = false;
        setFormDisabled(false);
        const detail = error instanceof Error && error.message ? `${error.message} ` : "";
        statusEl.textContent = retryLocked ? `${detail}Saving is unconfirmed. Retry save sends the original comment without creating a duplicate. You can also copy the text and check Backline before starting another comment.` : `Could not post your comment. ${detail}Your draft is still here. You can edit it and try again, or copy the text.`;
        textarea.focus({ preventScroll: true });
      });
    }
    closeButton.addEventListener("click", cancel);
    cancelButton.addEventListener("click", cancel);
    submitButton.addEventListener("click", submit);
    copyButton.addEventListener("click", () => {
      void navigator.clipboard?.writeText(textarea.value).then(() => {
        if (!closed) statusEl.textContent = retryLocked ? "Text copied. Saving is still unconfirmed; retry this save or check Backline." : "Comment text copied. Your draft is still here.";
      }).catch(() => {
        if (closed) return;
        textarea.focus({ preventScroll: true });
        textarea.select();
        statusEl.textContent = `Copy is unavailable here. Your text is selected; press ${isMac ? "\u2318" : "Ctrl"}+C to copy it.`;
      });
      if (!navigator.clipboard) {
        textarea.focus({ preventScroll: true });
        textarea.select();
        statusEl.textContent = `Your text is selected; press ${isMac ? "\u2318" : "Ctrl"}+C to copy it.`;
      }
    });
    textarea.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        submit();
      }
    });
    textarea.addEventListener("input", () => {
      discardArmedUntil = 0;
      copyButton.hidden = !textarea.value.trim();
      if (statusEl.textContent === "Post or cancel this comment first.") statusEl.textContent = "";
    });
    composer.addEventListener("animationend", () => composer.classList.remove("bl-nudge"));
    composer.addEventListener("keydown", (event) => {
      if (event.key !== "Escape" || submitted) return;
      event.preventDefault();
      if (!hasDraft() || Date.now() < discardArmedUntil) {
        cancel();
        return;
      }
      discardArmedUntil = Date.now() + 3e3;
      statusEl.textContent = retryLocked ? "Saving is unconfirmed. Press Esc again to close; check Backline before posting another comment." : "Press Esc again to discard this comment.";
    });
    textarea.addEventListener("paste", (event) => {
      const files = pastedImageFiles(event.clipboardData);
      if (files.length === 0) return;
      event.preventDefault();
      if (submitted || retryLocked) return;
      attachments.addFiles(files);
    });
    const stopAutoGrow = autoGrowTextarea(textarea, () => placeCard(composer, x, y));
    const outsideClickHandler = (event) => {
      if (event.composedPath().includes(composer)) return;
      if (composer.offsetParent === null) return;
      if (hasDraft()) nudge();
      else cancel();
    };
    setTimeout(() => document.addEventListener("click", outsideClickHandler, true), 0);
    setTimeout(() => textarea.focus({ preventScroll: true }), 30);
    return {
      setStatus: (text) => {
        statusEl.textContent = text;
      },
      setCloseDelay: (ms) => {
        closeDelay = ms;
      },
      setRetryLocked: (locked) => {
        retryLocked = locked;
        submitButton.innerHTML = `${svg(ARROW_ICON, 2.2)}${locked ? "Retry save" : "Post comment"}`;
        cancelButton.textContent = locked ? "Close" : "Cancel";
        closeButton.setAttribute("aria-label", locked ? "Close comment" : "Cancel comment");
      },
      close: removeComposer
    };
  }

  // ../widget/src/status.ts
  var WORKFLOW_STATUSES = ["todo", "in_progress", "in_review", "blocked", "resolved", "wont_fix"];
  var STATUS_LABELS = {
    todo: "Not started",
    in_progress: "In progress",
    in_review: "In review",
    blocked: "Blocked",
    resolved: "Resolved",
    wont_fix: "Won't fix"
  };
  var STATUS_COLORS = {
    todo: "#94A3B8",
    in_progress: "#F59E0B",
    in_review: "#396586",
    blocked: "#A33D1F",
    resolved: "#22C55E",
    wont_fix: "#64748B"
  };

  // ../widget/src/ui-thread-reply.ts
  function setupThreadReply(view, x, y, layer, post) {
    const form = document.createElement("form");
    form.className = "bl-cv-reply-form";
    form.innerHTML = `
    <label class="bl-cp-lbl">Reply to this thread
      <textarea aria-label="Reply to this thread" placeholder="Write a reply\u2026" maxlength="10000" required></textarea>
    </label>
    <p class="bl-cv-visibility">${layer === "team" ? "Team only" : "Visible to client reviewers"}</p>
    <p class="bl-status" role="status" aria-live="polite"></p>
    <button type="button" class="bl-copy-draft" hidden>Copy reply text</button>
    <div class="bl-cp-foot">
      <button type="button" class="bl-cp-cancel bl-reply-clear">Clear reply</button>
      <button type="submit" class="bl-submit">Post reply</button>
    </div>
    <div class="bl-reply-discard" hidden>
      <p>Discard this reply? If saving is unconfirmed, check Backline before posting it again.</p>
      <button type="button" class="bl-cp-cancel bl-reply-keep">Keep writing</button>
      <button type="button" class="bl-cp-cancel bl-reply-discard-confirm">Discard reply</button>
    </div>`;
    view.querySelector(".bl-cp-body").appendChild(form);
    const text = form.querySelector("textarea");
    const message = form.querySelector(".bl-status");
    const submit = form.querySelector(".bl-submit");
    const clear = form.querySelector(".bl-reply-clear");
    const copy = form.querySelector(".bl-copy-draft");
    const discard = form.querySelector(".bl-reply-discard");
    let request = null;
    let pending = false;
    let disposed = false;
    let afterDiscard = null;
    let slowTimer = null;
    const hasDraft = () => !disposed && (pending || request !== null || text.value.trim() !== "");
    function nudge() {
      if (disposed) return;
      view.scrollIntoView({ block: "nearest" });
      text.focus({ preventScroll: true });
      if (!pending && !request) message.textContent = "Post or clear this reply before switching comments or review modes.";
    }
    const unregister = registerRelatedDraft({ hasDraft, nudge });
    function render() {
      text.readOnly = pending || request !== null;
      submit.disabled = pending;
      clear.disabled = pending;
      copy.hidden = !text.value.trim();
      submit.textContent = pending ? "Saving reply\u2026" : request ? "Retry reply save" : "Post reply";
      form.setAttribute("aria-busy", String(pending));
      placeCard(view, x, y);
    }
    function askDiscard(continuation) {
      if (!hasDraft()) return true;
      if (pending) {
        message.textContent = "Wait for this reply save to finish. Keep this page open.";
        nudge();
        return false;
      }
      afterDiscard = continuation;
      discard.hidden = false;
      form.querySelector(".bl-reply-keep").focus();
      placeCard(view, x, y);
      return false;
    }
    function reset() {
      request = null;
      text.value = "";
      discard.hidden = true;
      afterDiscard = null;
      render();
    }
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (pending || disposed) return;
      if (!request) {
        const body = text.value.trim();
        if (!body) {
          message.textContent = "Write a reply before posting.";
          text.focus();
          return;
        }
        request = { body, layer, client_request_id: crypto.randomUUID() };
      }
      const original = request;
      pending = true;
      discard.hidden = true;
      afterDiscard = null;
      message.textContent = "Saving reply\u2026";
      render();
      slowTimer = setTimeout(() => {
        if (!disposed && pending) message.textContent = "Still waiting for Backline. Keep this page open; do not post the reply again in another tab.";
      }, 2e4);
      void Promise.resolve().then(() => post(original)).then(() => {
        if (disposed) return;
        pending = false;
        reset();
        message.textContent = "Reply posted.";
      }).catch((error) => {
        if (disposed) return;
        pending = false;
        const detail = error instanceof Error && error.message ? `${error.message} ` : "";
        message.textContent = `${detail}Saving is unconfirmed. Retry sends the same reply. You can copy the text and check Backline before clearing it.`;
        render();
      }).finally(() => {
        if (slowTimer) clearTimeout(slowTimer);
        slowTimer = null;
      });
    });
    text.addEventListener("input", () => {
      discard.hidden = true;
      afterDiscard = null;
      render();
    });
    text.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        form.requestSubmit();
      }
    });
    clear.addEventListener("click", () => {
      if (askDiscard(() => {
        reset();
        message.textContent = "Reply cleared.";
        text.focus();
      })) {
        reset();
        text.focus();
      }
    });
    form.querySelector(".bl-reply-keep").addEventListener("click", () => {
      discard.hidden = true;
      afterDiscard = null;
      text.focus();
      placeCard(view, x, y);
    });
    form.querySelector(".bl-reply-discard-confirm").addEventListener("click", () => {
      if (pending) return;
      const continuation = afterDiscard;
      reset();
      continuation?.();
    });
    copy.addEventListener("click", () => {
      const manualCopy = () => {
        if (disposed) return;
        text.focus();
        text.select();
        message.textContent = "Your reply text is selected. Press Ctrl+C or \u2318C to copy it.";
      };
      if (!navigator.clipboard) {
        manualCopy();
        return;
      }
      void navigator.clipboard.writeText(text.value).then(() => {
        if (!disposed) message.textContent = "Reply text copied. Your draft is still here; saving status has not changed.";
      }).catch(manualCopy);
    });
    const beforeUnload = (event) => {
      if (!hasDraft()) return;
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", beforeUnload);
    return {
      hasDraft,
      nudge,
      canClose: (close) => askDiscard(close),
      dispose: () => {
        disposed = true;
        unregister();
        if (slowTimer) clearTimeout(slowTimer);
        window.removeEventListener("beforeunload", beforeUnload);
        request = null;
        text.value = "";
        form.remove();
      }
    };
  }

  // ../widget/src/ui-comment-view.ts
  var CHEVRON_ICON = '<path d="M6 9l6 6 6-6"/>';
  var CHECK_ICON = '<path d="M5 12l5 5L20 7"/>';
  var statusLabel = (status) => STATUS_LABELS[status] ?? status;
  var statusColor = (status) => STATUS_COLORS[status] ?? STATUS_COLORS.todo;
  function replyTime(iso) {
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return "";
    return date.toLocaleString(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  }
  function replyHtml(reply) {
    return `<div class="bl-cv-reply">
    <div class="bl-cv-reply-head">
      <span class="bl-cv-reply-author">${escapeHtml(reply.authorName)}</span>
      <span class="bl-cv-reply-time">${escapeHtml(replyTime(reply.createdAt))}</span>
    </div>
    <p class="bl-cv-reply-body"></p>
  </div>`;
  }
  function attachmentHtml(attachment) {
    const href = escapeHtml(attachment.url);
    const name = escapeHtml(attachment.filename);
    if (attachment.content_type.startsWith("image/")) {
      return `<a class="bl-attachment-link bl-cv-thumb" href="${href}" target="_blank" rel="noopener noreferrer" title="${name}"><img src="${href}" alt="${name}" /></a>`;
    }
    return `<a class="bl-attachment-link" href="${href}" target="_blank" rel="noopener noreferrer" title="${name}">${attachmentIcon()}<span class="bl-attachment-name">${name}</span></a>`;
  }
  function statusHtml(editable) {
    const pill = '<span class="bl-cv-status-dot" aria-hidden="true"></span><span class="bl-cv-status-label"></span>';
    if (!editable) return `<span class="bl-cv-status" title="Status">${pill}</span>`;
    const options = WORKFLOW_STATUSES.map(
      (status) => `<button type="button" class="bl-cv-status-opt" role="menuitemradio" aria-checked="false" data-status="${status}">
        <span class="bl-cv-status-dot" style="background: ${statusColor(status)}" aria-hidden="true"></span>
        <span>${escapeHtml(statusLabel(status))}</span>
        ${svg(CHECK_ICON, 2.2)}
      </button>`
    ).join("");
    return `
    <div class="bl-cv-status-wrap">
      <button type="button" class="bl-cv-status" aria-haspopup="menu" aria-expanded="false" title="Change status">${pill}${svg(CHEVRON_ICON, 2, 10)}</button>
      <div class="bl-cv-status-menu" role="menu" aria-label="Change status" hidden>${options}</div>
    </div>`;
  }
  function openCommentView(shadow, x, y, comment, onClose, onStatusChange = null, onReply = null) {
    const view = document.createElement("div");
    view.className = "bl-card bl-thread";
    view.setAttribute("role", "dialog");
    view.setAttribute("aria-label", `Comment by ${comment.authorName}`);
    view.innerHTML = `
    ${cardHeaderHtml({
      authorName: comment.authorName,
      title: comment.authorName,
      titleClass: "bl-thread-message-author",
      pagePath: comment.pagePath,
      closeLabel: "Close comment",
      trailingHtml: statusHtml(onStatusChange !== null)
    })}
    <div class="bl-cp-body">
      <div class="bl-cv-content"></div>
      ${onStatusChange ? '<p class="bl-status" role="status" aria-live="polite"></p>' : ""}
    </div>
  `;
    const content = view.querySelector(".bl-cv-content");
    function renderContent(data) {
      content.innerHTML = `
      <p class="bl-thread-message-body bl-cv-text"></p>
      ${data.screenshotUrl ? `<a class="bl-attachment-link bl-cv-screenshot" href="${escapeHtml(data.screenshotUrl)}" target="_blank" rel="noopener noreferrer">View captured screenshot</a>` : data.captureStatus === "failed" ? '<p class="bl-cv-capture-warning">Automatic screenshot unavailable. The comment and its location were saved.</p>' : ""}
      ${data.tags.length > 0 ? `<div class="bl-cp-sec">
              <span class="bl-cp-lbl">TAGGED AS</span>
              <div class="bl-cp-tags">
                ${data.tags.map((tag) => `<span class="bl-cp-tag bl-is-on">${svg(TAG_ICONS[tag] ?? "")}${escapeHtml(tag)}</span>`).join("")}
              </div>
            </div>` : ""}
      ${data.attachments.length > 0 ? `<div class="bl-cv-files">${data.attachments.map(attachmentHtml).join("")}</div>` : ""}
      ${data.replies.length > 0 ? `<div class="bl-cv-replies">${data.replies.map(replyHtml).join("")}</div>` : ""}
    `;
      content.querySelector(".bl-cv-text").textContent = data.body;
      content.querySelectorAll(".bl-cv-reply-body").forEach((el, i) => {
        el.textContent = data.replies[i].body;
      });
    }
    renderContent(comment);
    const pill = view.querySelector(".bl-cv-status");
    const trigger = pill instanceof HTMLButtonElement ? pill : null;
    const wrap = view.querySelector(".bl-cv-status-wrap");
    const menu = view.querySelector(".bl-cv-status-menu");
    const message = view.querySelector(".bl-status");
    const options = Array.from(view.querySelectorAll(".bl-cv-status-opt"));
    let currentStatus = comment.status;
    let pending = false;
    function renderStatus(status) {
      pill.querySelector(".bl-cv-status-dot").style.background = statusColor(status);
      pill.querySelector(".bl-cv-status-label").textContent = statusLabel(status);
      trigger?.setAttribute("aria-label", `Status: ${statusLabel(status)}. Change status`);
      for (const option of options) {
        option.setAttribute("aria-checked", String(option.dataset.status === status));
      }
    }
    renderStatus(currentStatus);
    shadow.appendChild(view);
    const stopPlacement = observeCardPlacement(view, x, y);
    const reply = onReply ? setupThreadReply(view, x, y, comment.layer ?? "client", onReply) : null;
    const menuOpen = () => menu !== null && !menu.hidden;
    function openMenu() {
      if (!menu || !trigger) return;
      menu.classList.remove("bl-is-up");
      menu.hidden = false;
      trigger.setAttribute("aria-expanded", "true");
      const menuRect = menu.getBoundingClientRect();
      const triggerRect = trigger.getBoundingClientRect();
      if (menuRect.bottom > window.innerHeight - 8 && triggerRect.top - menuRect.height - 6 >= 8) {
        menu.classList.add("bl-is-up");
      }
      (options.find((option) => option.dataset.status === currentStatus) ?? options[0])?.focus();
    }
    function closeMenu(returnFocus) {
      if (!menu || !trigger || menu.hidden) return;
      menu.hidden = true;
      trigger.setAttribute("aria-expanded", "false");
      if (returnFocus) trigger.focus();
    }
    async function chooseStatus(status) {
      closeMenu(true);
      if (!onStatusChange || !trigger || pending || status === currentStatus) return;
      const previous = currentStatus;
      pending = true;
      trigger.setAttribute("aria-busy", "true");
      if (message) message.textContent = "";
      currentStatus = status;
      renderStatus(status);
      try {
        currentStatus = await onStatusChange(status);
      } catch {
        currentStatus = previous;
        if (message) message.textContent = "Couldn't change the status. Please try again.";
      } finally {
        pending = false;
        trigger.removeAttribute("aria-busy");
        renderStatus(currentStatus);
      }
    }
    if (trigger && menu && wrap) {
      trigger.addEventListener("click", () => {
        if (pending) return;
        if (menuOpen()) closeMenu(false);
        else openMenu();
      });
      for (const option of options) {
        option.addEventListener("click", () => void chooseStatus(option.dataset.status ?? currentStatus));
      }
      menu.addEventListener("keydown", (event) => {
        const index = options.indexOf(event.target);
        let next = -1;
        if (event.key === "ArrowDown") next = (index + 1) % options.length;
        else if (event.key === "ArrowUp") next = (index - 1 + options.length) % options.length;
        else if (event.key === "Home") next = 0;
        else if (event.key === "End") next = options.length - 1;
        else if (event.key === "Tab") closeMenu(false);
        if (next === -1) return;
        event.preventDefault();
        options[next].focus();
      });
      view.addEventListener("click", (event) => {
        if (menuOpen() && !event.composedPath().includes(wrap)) closeMenu(false);
      });
    }
    let closed = false;
    function close(force = false) {
      if (closed) return true;
      if (!force && reply && !reply.canClose(() => close(true))) return false;
      closed = true;
      reply?.dispose();
      stopPlacement();
      document.removeEventListener("click", outsideClickHandler, true);
      document.removeEventListener("keydown", escapeHandler, true);
      view.remove();
      onClose();
      return true;
    }
    view.querySelector(".bl-cancel").addEventListener("click", () => close());
    const outsideClickHandler = (event) => {
      if (!event.composedPath().includes(view)) {
        if (reply?.hasDraft()) reply.nudge();
        else close();
      }
    };
    const escapeHandler = (event) => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      if (menuOpen()) closeMenu(true);
      else close();
    };
    setTimeout(() => {
      if (closed) return;
      document.addEventListener("click", outsideClickHandler, true);
      document.addEventListener("keydown", escapeHandler, true);
    }, 0);
    return {
      close,
      setStatus: (status) => {
        if (pending || status === currentStatus) return;
        currentStatus = status;
        renderStatus(status);
      },
      update: (data) => {
        if (closed) return;
        renderContent(data);
        placeCard(view, x, y);
      }
    };
  }

  // ../widget/src/hash.ts
  async function sha256(input) {
    const bytes = new TextEncoder().encode(input);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return `sha256:${hex}`;
  }

  // ../widget/src/node-identity.ts
  var PRIVATE_SELECTOR = 'input,textarea,select,[contenteditable=""],[contenteditable="true"],[contenteditable="plaintext-only"],[data-backline-private]';
  function isPrivateReviewElement(el) {
    return el.closest(PRIVATE_SELECTOR) !== null;
  }
  function getDirectText(el) {
    if (isPrivateReviewElement(el)) return "";
    let text = "";
    for (const child of el.childNodes) {
      if (child.nodeType === Node.TEXT_NODE) {
        text += child.textContent ?? "";
      }
    }
    return text.replace(/\s+/g, " ").trim();
  }
  function getStableAttributes(el) {
    if (isPrivateReviewElement(el)) return {};
    const attrs = {};
    const id = el.getAttribute("id");
    if (id) attrs.id = id;
    const testId = el.getAttribute("data-testid");
    if (testId) attrs["data-testid"] = testId;
    const className = el.getAttribute("class");
    if (className) attrs.class = className;
    return attrs;
  }
  async function computeNodeHash(el) {
    const tag = el.tagName.toLowerCase();
    const attributes = getStableAttributes(el);
    const text = getDirectText(el);
    return sha256(`${tag}|${JSON.stringify(attributes)}|${text.toLowerCase()}`);
  }
  function ancestorChainFromBody(el) {
    if (el === document.body) return [document.body];
    const chain = [el];
    let current = el.parentElement;
    while (current && current !== document.body) {
      chain.unshift(current);
      current = current.parentElement;
    }
    chain.unshift(document.body);
    return chain;
  }
  async function computeIdentity(el) {
    const chain = ancestorChainFromBody(el);
    let ancestorPathHash = await sha256("root");
    let nodeHash = "";
    for (const node of chain) {
      nodeHash = await computeNodeHash(node);
      ancestorPathHash = await sha256(`${ancestorPathHash}|${nodeHash}`);
    }
    return { nodeHash, ancestorPathHash };
  }

  // ../widget/src/simhash.ts
  function fnv1a(str) {
    let hash = 0xcbf29ce484222325n;
    const prime = 0x100000001b3n;
    const mask = 0xffffffffffffffffn;
    for (let i = 0; i < str.length; i++) {
      hash ^= BigInt(str.charCodeAt(i));
      hash = hash * prime & mask;
    }
    return hash;
  }
  function trigrams(text) {
    const padded = `  ${text}  `;
    const result = [];
    for (let i = 0; i <= padded.length - 3; i++) {
      result.push(padded.slice(i, i + 3));
    }
    return result.length > 0 ? result : [text];
  }
  function computeSimhash(text) {
    if (text.length === 0) return "0".repeat(16);
    const bitCounts = new Array(64).fill(0);
    for (const shingle of trigrams(text)) {
      const h = fnv1a(shingle);
      for (let bit = 0; bit < 64; bit++) {
        const isSet = (h & 1n << BigInt(bit)) !== 0n;
        bitCounts[bit] += isSet ? 1 : -1;
      }
    }
    let signature = 0n;
    for (let bit = 0; bit < 64; bit++) {
      if (bitCounts[bit] > 0) signature |= 1n << BigInt(bit);
    }
    return signature.toString(16).padStart(16, "0");
  }

  // ../widget/src/anchor.ts
  function nthOfTypeIndex(el) {
    let index = 1;
    let sibling = el.previousElementSibling;
    while (sibling) {
      if (sibling.tagName === el.tagName) index += 1;
      sibling = sibling.previousElementSibling;
    }
    return index;
  }
  function selectorSegment(el) {
    const tag = el.tagName.toLowerCase();
    if (!isPrivateReviewElement(el) && el.id) return `${tag}#${el.id}`;
    return `${tag}:nth-of-type(${nthOfTypeIndex(el)})`;
  }
  function buildSelectorPath(el) {
    const segments = [];
    let current = el;
    while (current && current !== document.body) {
      segments.unshift(selectorSegment(current));
      current = current.parentElement;
    }
    return `body > ${segments.join(" > ")}`;
  }
  function resolveAnchorElement(anchor) {
    try {
      return document.querySelector(anchor.dom_fingerprint.selector_path);
    } catch {
      return null;
    }
  }
  function waitForAnchorElement(anchor, timeoutMs = 8e3) {
    const immediate = resolveAnchorElement(anchor);
    if (immediate) return Promise.resolve(immediate);
    return new Promise((resolve) => {
      let settled = false;
      const observer = new MutationObserver(check);
      function finish(element) {
        if (settled) return;
        settled = true;
        observer.disconnect();
        clearInterval(pollId);
        clearTimeout(timeoutId);
        resolve(element);
      }
      function check() {
        const element = resolveAnchorElement(anchor);
        if (element) finish(element);
      }
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true
      });
      const pollId = setInterval(check, 500);
      const timeoutId = setTimeout(() => finish(null), timeoutMs);
    });
  }
  function clamp01(value) {
    return Math.min(1, Math.max(0, value));
  }
  function clickOffsetPct(el, clickX, clickY) {
    const rect = el.getBoundingClientRect();
    return {
      x: rect.width > 0 ? clamp01((clickX - (rect.left + window.scrollX)) / rect.width) : 0,
      y: rect.height > 0 ? clamp01((clickY - (rect.top + window.scrollY)) / rect.height) : 0
    };
  }
  function anchorOffsetPct(anchor) {
    const fingerprint = anchor.dom_fingerprint;
    if (fingerprint.click_offset_pct) return fingerprint.click_offset_pct;
    if (fingerprint.region_box_pct) return { x: fingerprint.region_box_pct.x, y: fingerprint.region_box_pct.y };
    return { x: 0, y: 0 };
  }
  async function computeAnchor(el, clickX, clickY) {
    const tag = el.tagName.toLowerCase();
    const attributes = getStableAttributes(el);
    const { nodeHash, ancestorPathHash } = await computeIdentity(el);
    const normalizedText = getDirectText(el).toLowerCase();
    const domFingerprint = {
      selector_path: buildSelectorPath(el),
      tag,
      attributes,
      node_hash: nodeHash,
      ancestor_path_hash: ancestorPathHash,
      click_offset_pct: clickOffsetPct(el, clickX, clickY)
    };
    return {
      tier: 1,
      type: "point",
      dom_fingerprint: domFingerprint,
      text_fingerprint: {
        normalized_text: normalizedText,
        text_similarity_hash: computeSimhash(normalizedText)
      }
    };
  }
  async function computeRegionAnchor(el, rect) {
    const tag = el.tagName.toLowerCase();
    const attributes = getStableAttributes(el);
    const { nodeHash, ancestorPathHash } = await computeIdentity(el);
    const normalizedText = getDirectText(el).toLowerCase();
    const elRect = el.getBoundingClientRect();
    const region_box_pct = {
      x: elRect.width > 0 ? clamp01((rect.x - (elRect.left + window.scrollX)) / elRect.width) : 0,
      y: elRect.height > 0 ? clamp01((rect.y - (elRect.top + window.scrollY)) / elRect.height) : 0,
      width: elRect.width > 0 ? clamp01(rect.width / elRect.width) : 0,
      height: elRect.height > 0 ? clamp01(rect.height / elRect.height) : 0
    };
    return {
      tier: 1,
      type: "region",
      dom_fingerprint: {
        selector_path: buildSelectorPath(el),
        tag,
        attributes,
        node_hash: nodeHash,
        ancestor_path_hash: ancestorPathHash,
        region_box_pct
      },
      text_fingerprint: {
        normalized_text: normalizedText,
        text_similarity_hash: computeSimhash(normalizedText)
      }
    };
  }

  // ../widget/src/attachment-upload.ts
  async function uploadThroughApi(api, projectId, body, filename) {
    try {
      const form = new FormData();
      form.append("project_id", projectId);
      form.append("file", body, filename);
      const stored = await api.upload("/api/v1/uploads/direct", form);
      return stored.key;
    } catch {
      return null;
    }
  }
  async function uploadScreenshot(api, projectId, blob) {
    return uploadThroughApi(api, projectId, blob, "screenshot.jpg");
  }
  async function uploadAttachment(api, projectId, file) {
    const contentType = file.type || "application/octet-stream";
    const key = await uploadThroughApi(api, projectId, file, file.name);
    return key ? { key, filename: file.name, content_type: contentType } : null;
  }

  // ../widget/src/screenshot.ts
  function collectInlineStyles() {
    let css = "";
    for (const sheet of Array.from(document.styleSheets)) {
      try {
        for (const rule of Array.from(sheet.cssRules)) {
          css += rule.cssText + "\n";
        }
      } catch {
      }
    }
    return css;
  }
  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Failed to rasterize snapshot SVG."));
      img.src = src;
    });
  }
  async function captureScreenshot() {
    try {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const clone = document.body.cloneNode(true);
      clone.querySelectorAll("[data-backline-root]").forEach((node) => node.remove());
      const css = collectInlineStyles();
      const serializedBody = new XMLSerializer().serializeToString(clone);
      const bodyBackground = window.getComputedStyle(document.body).backgroundColor;
      const svgString = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml" style="background:${bodyBackground};min-height:${height}px;"><style>${css}</style>${serializedBody}</div></foreignObject></svg>`;
      const dataUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgString)}`;
      const image = await loadImage(dataUrl);
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) return null;
      ctx.drawImage(image, 0, 0, width, height);
      return await new Promise((resolve) => {
        canvas.toBlob((blob) => resolve(blob), "image/jpeg", 0.8);
      });
    } catch {
      return null;
    }
  }

  // ../widget/src/user-agent.ts
  function detectBrowser(ua) {
    if (/EdgiOS|Edg\//.test(ua)) return "Edge";
    if (/OPR\/|Opera/.test(ua)) return "Opera";
    if (/SamsungBrowser/.test(ua)) return "Samsung Internet";
    if (/CriOS|Chrome/.test(ua)) return "Chrome";
    if (/FxiOS|Firefox/.test(ua)) return "Firefox";
    if (/Version\/.*Safari/.test(ua) || /^((?!Chrome|Android).)*Safari/.test(ua)) return "Safari";
    return "Unknown";
  }
  function detectOs(ua) {
    if (/iPhone|iPad|iPod/.test(ua)) return "iOS";
    if (/Android/.test(ua)) return "Android";
    if (/Mac OS X/.test(ua)) return "macOS";
    if (/Windows/.test(ua)) return "Windows";
    if (/Linux/.test(ua)) return "Linux";
    return "Unknown";
  }
  function detectDeviceType(ua) {
    if (/iPad/.test(ua) || /Android/.test(ua) && !/Mobile/.test(ua)) return "tablet";
    if (/Mobi|iPhone|iPod/.test(ua)) return "mobile";
    return "desktop";
  }
  function parseUserAgent(ua) {
    return {
      browser: detectBrowser(ua),
      os: detectOs(ua),
      device_type: detectDeviceType(ua)
    };
  }

  // ../widget/src/dom-snapshot.ts
  var STYLE_SUBSET_PROPERTIES = ["display", "font-size", "color", "background-color"];
  var MAX_NODES = 5e3;
  var MAX_DEPTH = 80;
  var MAX_TEXT_LENGTH = 2e4;
  var MAX_SNAPSHOT_BYTES = 4 * 1024 * 1024;
  function requireCurrent(state) {
    if (location.href !== state.documentUrl) throw new Error("The page changed during version capture. Reopen review on the current page.");
    if (performance.now() - state.startedAt > 1e4) throw new Error("This page took too long to capture. Comments still work; retry its version when the page settles.");
  }
  function getStyleSubset(el) {
    const computed = window.getComputedStyle(el);
    const subset = {};
    for (const prop of STYLE_SUBSET_PROPERTIES) {
      subset[prop] = computed.getPropertyValue(prop);
    }
    return subset;
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    return window.getComputedStyle(el).display !== "none";
  }
  async function buildNode(el, parentAncestorHash, nodesIndex, state, depth) {
    requireCurrent(state);
    if (state.elements.has(el)) throw new Error("The page structure changed during capture. Retry when the page settles.");
    state.elements.add(el);
    state.count += 1;
    if (state.count > MAX_NODES || depth > MAX_DEPTH) throw new Error("This page is too complex for a complete version capture. Comments still work.");
    if (state.count % 40 === 0) {
      await new Promise((resolve) => setTimeout(resolve, 0));
      requireCurrent(state);
    }
    const nodeId = `n_${state.count}`;
    const tag = el.tagName.toLowerCase();
    const privateElement = isPrivateReviewElement(el);
    const attributes = getStableAttributes(el);
    if (!privateElement) {
      if (el.childNodes.length > 2e4) throw new Error("This page is too complex for a complete version capture. Comments still work.");
      let rawTextLength = 0;
      for (const child of el.childNodes) {
        if (child.nodeType === Node.TEXT_NODE) rawTextLength += child.textContent?.length ?? 0;
        if (rawTextLength > 2e5) throw new Error("A page element is too large for version capture. Comments still work.");
      }
    }
    const text = getDirectText(el);
    if (text.length > MAX_TEXT_LENGTH || Object.values(attributes).some((value) => value.length > 4e3)) throw new Error("A page element is too large for version capture. Comments still work.");
    const rect = el.getBoundingClientRect();
    const nodeHash = await sha256(`${tag}|${JSON.stringify(attributes)}|${text.toLowerCase()}`);
    const ancestorPathHash = await sha256(`${parentAncestorHash}|${nodeHash}`);
    const children = [];
    if (!privateElement) {
      for (const child of Array.from(el.children)) {
        state.scanned += 1;
        if (state.scanned > 2e4) throw new Error("This page is too complex for a complete version capture. Comments still work.");
        if (state.scanned % 100 === 0) {
          await new Promise((resolve) => setTimeout(resolve, 0));
          requireCurrent(state);
        }
        if (child.hasAttribute("data-backline-root")) continue;
        if (!isVisible(child)) continue;
        children.push(await buildNode(child, ancestorPathHash, nodesIndex, state, depth + 1));
      }
    }
    const record = {
      tag,
      attributes,
      text,
      bounding_box: { x: rect.x, y: rect.y, w: rect.width, h: rect.height },
      computed_style_subset: privateElement ? {} : getStyleSubset(el),
      role: privateElement ? null : el.getAttribute("role"),
      accessible_name: privateElement ? null : el.getAttribute("aria-label") ?? (text || null),
      node_hash: nodeHash,
      ancestor_path_hash: ancestorPathHash,
      text_similarity_hash: computeSimhash(text)
    };
    if ((record.accessible_name?.length ?? 0) > MAX_TEXT_LENGTH || (record.role?.length ?? 0) > 256) throw new Error("A page element is too large for version capture. Comments still work.");
    state.bytes += new TextEncoder().encode(JSON.stringify(record)).byteLength;
    if (state.bytes > MAX_SNAPSHOT_BYTES - 512e3) throw new Error("This page version exceeds the capture size limit. Comments still work.");
    nodesIndex[nodeId] = record;
    return { node_id: nodeId, tag, children };
  }
  async function captureSnapshot() {
    const state = { count: 0, scanned: 0, bytes: 0, startedAt: performance.now(), documentUrl: location.href, elements: /* @__PURE__ */ new WeakSet() };
    const nodesIndex = {};
    const rootAncestorHash = await sha256("root");
    const nodeTree = await buildNode(document.body, rootAncestorHash, nodesIndex, state, 0);
    const allHashes = Object.values(nodesIndex).map((n) => n.node_hash).join("|");
    const fullPageHash = await sha256(allHashes);
    const snapshot = {
      viewport: { width: window.innerWidth, height: window.innerHeight },
      node_tree: nodeTree,
      nodes_index: nodesIndex,
      full_page_hash: fullPageHash
    };
    requireCurrent(state);
    if (new TextEncoder().encode(JSON.stringify(snapshot)).byteLength > MAX_SNAPSHOT_BYTES) throw new Error("This page version exceeds the capture size limit. Comments still work.");
    return snapshot;
  }

  // ../widget/src/page-registration.ts
  async function registerCurrentPage(api, projectId, url) {
    const page = await api.request("/api/v1/pages", {
      method: "POST",
      body: JSON.stringify({
        project_id: projectId,
        url,
        title: document.title || null
      })
    });
    const address = new URL(url);
    if (address.hash.startsWith("#/") || address.hash.startsWith("#!/")) {
      let registeredHash = "";
      try {
        registeredHash = new URL(page.url_normalized ?? "").hash;
      } catch {
      }
      if (registeredHash !== address.hash) {
        throw new Error("This Backline server could not register this route separately. Return to Backline and reopen review after the server is updated. Your existing feedback is still available there.");
      }
    }
    return page.id;
  }
  async function submitPageSnapshot(api, pageId, expectedDocumentUrl = location.href) {
    if (location.href !== expectedDocumentUrl) throw new Error("The page changed. Reopen review on the current page before capturing a version.");
    const snapshot = await captureSnapshot();
    if (location.href !== expectedDocumentUrl) throw new Error("The page changed during version capture. Reopen review on the current page.");
    await api.request(`/api/v1/pages/${pageId}/snapshots`, {
      method: "POST",
      body: JSON.stringify(snapshot)
    });
  }
  var captureGeneration = /* @__PURE__ */ new WeakMap();
  function capturePageVersion(api, pageId, shadow, expectedDocumentUrl) {
    const generation = (captureGeneration.get(shadow) ?? 0) + 1;
    captureGeneration.set(shadow, generation);
    shadow.querySelector("[data-backline-capture-notice]")?.remove();
    let running = false;
    const current = () => shadow.host.isConnected && captureGeneration.get(shadow) === generation && location.href === expectedDocumentUrl;
    function notice(message, pending) {
      if (!current()) return;
      shadow.querySelector("[data-backline-capture-notice]")?.remove();
      const panel = document.createElement("div");
      panel.setAttribute("data-backline-capture-notice", "true");
      panel.setAttribute("role", "status");
      panel.style.cssText = "position:fixed;right:16px;bottom:100px;z-index:2147483646;width:min(320px,calc(100vw - 32px));max-height:180px;overflow:auto;box-sizing:border-box;padding:12px;background:#fff;color:#20231e;border:1px solid #ccd2c8;border-radius:6px;font:12px/1.5 system-ui;box-shadow:0 4px 20px #0002;pointer-events:auto";
      const text = document.createElement("p");
      text.style.margin = "0 0 8px";
      text.textContent = message;
      panel.appendChild(text);
      if (!pending) {
        const retry = document.createElement("button");
        retry.type = "button";
        retry.textContent = "Retry version capture";
        retry.addEventListener("click", () => {
          if (location.href !== expectedDocumentUrl) {
            text.textContent = "The page changed. Reopen review on the current page before capturing its version.";
            retry.disabled = true;
            return;
          }
          if (!running) void run();
        });
        panel.appendChild(retry);
      }
      const close = document.createElement("button");
      close.type = "button";
      close.textContent = "Dismiss";
      close.style.marginLeft = "8px";
      close.addEventListener("click", () => panel.remove());
      panel.appendChild(close);
      shadow.appendChild(panel);
    }
    async function run() {
      if (running || !current()) return;
      running = true;
      shadow.querySelector("[data-backline-capture-notice]")?.remove();
      const slow = window.setTimeout(() => notice("Page version capture is still awaiting a response. Feedback can still be saved.", true), 2e4);
      try {
        await submitPageSnapshot(api, pageId, expectedDocumentUrl);
        if (current()) shadow.querySelector("[data-backline-capture-notice]")?.remove();
      } catch (error) {
        if (!(error instanceof WidgetApiError && [401, 403].includes(error.status))) {
          notice(`Page version could not be captured. Feedback can still be saved. ${error instanceof Error ? error.message : "Try again when the page settles."}`, false);
        }
      } finally {
        window.clearTimeout(slow);
        running = false;
      }
    }
    void run();
  }

  // ../widget/src/position-tracker.ts
  var tracked = /* @__PURE__ */ new Set();
  var rafId = null;
  function intersectsViewport(rect) {
    return rect.bottom > 0 && rect.top < window.innerHeight && rect.right > 0 && rect.left < window.innerWidth;
  }
  function tick() {
    for (const anchor of tracked) {
      const el = anchor.resolve();
      const rect = el?.getBoundingClientRect();
      if (rect && intersectsViewport(rect)) {
        const x = rect.left + window.scrollX;
        const y = rect.top + window.scrollY;
        const key = `${x}:${y}:${rect.width}:${rect.height}`;
        if (key !== anchor.lastKey) {
          anchor.lastKey = key;
          anchor.onUpdate({ x, y, width: rect.width, height: rect.height });
        }
      } else if (anchor.lastKey !== "gone") {
        anchor.lastKey = "gone";
        anchor.onUpdate(null);
      }
    }
    rafId = tracked.size > 0 ? requestAnimationFrame(tick) : null;
  }
  function trackAnchor(resolve, onUpdate) {
    const entry = { resolve, onUpdate, lastKey: "" };
    tracked.add(entry);
    if (rafId === null) rafId = requestAnimationFrame(tick);
    return () => {
      tracked.delete(entry);
    };
  }

  // ../widget/src/thread-manager.ts
  var CLOSED_STATUSES = /* @__PURE__ */ new Set(["resolved", "wont_fix"]);
  function createThreadManager({
    shadow,
    pagePath = () => window.location.pathname,
    statusUpdater = () => null,
    replyPoster = () => null
  }) {
    const threadMessages = /* @__PURE__ */ new Map();
    const pinsByTopId = /* @__PURE__ */ new Map();
    let openThread = null;
    let generation = 0;
    function trackPinPosition(pin, resolve, offset = { x: 0, y: 0 }) {
      return trackAnchor(resolve, (box) => {
        if (box) {
          const shift = typeof offset === "function" ? offset(box) : offset;
          pin.style.left = `${box.x + shift.x}px`;
          pin.style.top = `${box.y + shift.y}px`;
          pin.style.display = "";
        } else {
          pin.style.display = "none";
        }
      });
    }
    function createRegionOverlay(anchor, resolve) {
      const box = anchor.dom_fingerprint.region_box_pct;
      if (anchor.type !== "region" || !box) return null;
      const overlay = document.createElement("div");
      overlay.className = "bl-region";
      shadow.appendChild(overlay);
      const untrack = trackAnchor(resolve, (el) => {
        if (!el) {
          overlay.style.display = "none";
          return;
        }
        overlay.style.display = "";
        overlay.style.left = `${el.x + el.width * box.x}px`;
        overlay.style.top = `${el.y + el.height * box.y}px`;
        overlay.style.width = `${Math.max(4, el.width * box.width)}px`;
        overlay.style.height = `${Math.max(4, el.height * box.height)}px`;
      });
      return { overlay, untrack };
    }
    function applyPinState(topId) {
      const entry = pinsByTopId.get(topId);
      const top = threadMessages.get(topId)?.[0];
      if (!entry || !top) return;
      const closed = CLOSED_STATUSES.has(top.status);
      const active = openThread?.topId === topId;
      entry.pin.classList.toggle("bl-pin-closed", closed);
      entry.pin.classList.toggle("bl-pin-active", active);
      entry.regionOverlay?.classList.toggle("bl-region-closed", closed);
      entry.regionOverlay?.classList.toggle("bl-region-active", active);
    }
    function removeThreadPin(topId) {
      const entry = pinsByTopId.get(topId);
      if (!entry) return;
      entry.untrack();
      entry.pin.remove();
      entry.regionOverlay?.remove();
      pinsByTopId.delete(topId);
    }
    function adoptPin(topId, pin, untrack, regionOverlay) {
      const existing = pinsByTopId.get(topId);
      if (existing && existing.pin !== pin) removeThreadPin(topId);
      pinsByTopId.set(topId, { pin, untrack, regionOverlay });
      applyPinState(topId);
    }
    function renderThreadPin(top, stillCurrent = () => true) {
      const startedIn = generation;
      void waitForAnchorElement(top.anchor).then((element) => {
        if (!element || startedIn !== generation || !stillCurrent()) return;
        if (pinsByTopId.has(top.id) || !threadMessages.has(top.id)) return;
        const pct = anchorOffsetPct(top.anchor);
        const rect = element.getBoundingClientRect();
        const pin = renderPin(
          shadow,
          rect.left + window.scrollX + rect.width * pct.x,
          rect.top + window.scrollY + rect.height * pct.y,
          top.ticket_number
        );
        attachPinClickHandler(pin, top.id);
        const resolve = () => resolveAnchorElement(top.anchor);
        const untrackPin = trackPinPosition(pin, resolve, (box) => ({
          x: box.width * pct.x,
          y: box.height * pct.y
        }));
        const region = createRegionOverlay(top.anchor, resolve);
        pinsByTopId.set(top.id, {
          pin,
          regionOverlay: region?.overlay,
          untrack: () => {
            untrackPin();
            region?.untrack();
          }
        });
        applyPinState(top.id);
      });
    }
    function addThread(top, replies = [], stillCurrent) {
      threadMessages.set(top.id, [top, ...replies]);
      renderThreadPin(top, stillCurrent);
    }
    function viewData(thread) {
      const top = thread[0];
      return {
        authorName: top.author_name,
        body: top.body,
        status: top.status,
        layer: top.layer ?? "client",
        tags: top.tags ?? [],
        screenshotUrl: top.screenshot_url,
        captureStatus: top.capture_status,
        attachments: top.attachments ?? [],
        pagePath: pagePath(),
        replies: thread.slice(1).map((reply) => ({
          authorName: reply.author_name,
          body: reply.body,
          createdAt: reply.created_at
        }))
      };
    }
    function refreshOpenThread(topId) {
      if (openThread?.topId !== topId) return;
      const thread = threadMessages.get(topId);
      if (!thread || thread.length === 0) return;
      openThread.controls.setStatus(thread[0].status);
      openThread.controls.update(viewData(thread));
    }
    function closeOpenThread(force = false) {
      return openThread?.controls.close(force) ?? true;
    }
    function openThreadForComment(topId, x, y) {
      if (composerHasDraft()) {
        nudgeComposer();
        return;
      }
      if (!closeOpenThread()) return;
      const thread = threadMessages.get(topId);
      if (!thread || thread.length === 0) return;
      const updateStatus = statusUpdater();
      const postReply = replyPoster();
      const controls = openCommentView(
        shadow,
        x,
        y,
        viewData(thread),
        () => {
          if (openThread?.topId === topId) openThread = null;
          applyPinState(topId);
        },
        updateStatus ? async (status) => {
          const saved = await updateStatus(topId, status);
          setThreadStatus(topId, saved);
          return saved;
        } : null,
        postReply ? async (request) => {
          const saved = await postReply(topId, request);
          handleCommentCreated(saved, thread[0].page_id);
        } : null
      );
      openThread = { topId, controls };
      applyPinState(topId);
    }
    function setThreadStatus(topId, status) {
      const list = threadMessages.get(topId);
      if (list && list.length > 0) threadMessages.set(topId, [{ ...list[0], status }, ...list.slice(1)]);
      applyPinState(topId);
    }
    function handleStatusChanged(commentId, status) {
      if (!threadMessages.has(commentId)) return;
      setThreadStatus(commentId, status);
      if (openThread?.topId === commentId) openThread.controls.setStatus(status);
    }
    function handleCommentCreated(record, currentPageId) {
      if (record.parent_id === null) {
        if (record.page_id !== currentPageId || threadMessages.has(record.id)) return;
        addThread(record, [], () => record.page_id === currentPageId);
        return;
      }
      const list = threadMessages.get(record.parent_id);
      if (!list || list.some((c) => c.id === record.id)) return;
      const replies = [...list.slice(1), record].sort((a, b) => a.created_at.localeCompare(b.created_at));
      threadMessages.set(record.parent_id, [list[0], ...replies]);
      refreshOpenThread(record.parent_id);
    }
    function handleCommentUpdated(record) {
      if (record.parent_id === null) {
        const list2 = threadMessages.get(record.id);
        if (!list2) return false;
        threadMessages.set(record.id, [{ ...list2[0], ...record }, ...list2.slice(1)]);
        applyPinState(record.id);
        refreshOpenThread(record.id);
        return true;
      }
      const list = threadMessages.get(record.parent_id);
      if (!list) return false;
      const index = list.findIndex((c) => c.id === record.id);
      if (index <= 0) return false;
      const next = [...list];
      next[index] = { ...next[index], ...record };
      threadMessages.set(record.parent_id, next);
      refreshOpenThread(record.parent_id);
      return true;
    }
    function attachPinClickHandler(pin, topId) {
      pin.tabIndex = 0;
      pin.setAttribute("role", "button");
      pin.setAttribute("aria-label", "Open comment thread");
      pin.addEventListener("click", (event) => {
        event.stopPropagation();
        const x = parseFloat(pin.style.left);
        const y = parseFloat(pin.style.top);
        openThreadForComment(topId, x, y);
        if (window.parent !== window) {
          window.parent.postMessage({ type: "backline:comment-opened", commentId: topId }, "*");
        }
      });
      pin.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          pin.click();
        }
      });
    }
    function handleCommentDeleted(commentId, topId) {
      if (commentId === topId) {
        if (openThread?.topId === topId) closeOpenThread(true);
        removeThreadPin(topId);
        threadMessages.delete(topId);
        return;
      }
      const list = threadMessages.get(topId);
      if (!list) return;
      threadMessages.set(topId, list.filter((c) => c.id !== commentId));
      refreshOpenThread(topId);
    }
    function clearPage() {
      generation += 1;
      closeOpenThread(true);
      for (const topId of [...pinsByTopId.keys()]) removeThreadPin(topId);
      threadMessages.clear();
    }
    return {
      threadMessages,
      pinsByTopId,
      trackPinPosition,
      createRegionOverlay,
      removeThreadPin,
      adoptPin,
      addThread,
      clearPage,
      openThreadForComment,
      closeOpenThread,
      attachPinClickHandler,
      handleCommentCreated,
      handleCommentUpdated,
      handleCommentDeleted,
      handleStatusChanged
    };
  }

  // ../widget/src/region-drawer.ts
  function containerFor(start, rect) {
    const slack = 1;
    for (let el = start; el && el !== document.documentElement; el = el.parentElement) {
      const box = el.getBoundingClientRect();
      const left = box.left + window.scrollX;
      const top = box.top + window.scrollY;
      if (left <= rect.x + slack && top <= rect.y + slack && left + box.width >= rect.x + rect.width - slack && top + box.height >= rect.y + rect.height - slack) {
        return el;
      }
    }
    return document.body;
  }
  function setupRegionDrawer({
    shadow,
    api,
    projectId,
    pageId,
    documentUrl = location.href,
    browserOverride,
    threadManager,
    ownCommentIds,
    tooltip,
    composerDetails,
    onCommentCreated,
    screenshot = captureScreenshot,
    uploadScreenshotFile = uploadScreenshot,
    uploadFile = uploadAttachment,
    interceptEvents = false
  }) {
    let startX = 0;
    let startY = 0;
    let isDrawing = false;
    let overlay = null;
    let target = null;
    const previousCursor = document.body.style.cursor;
    document.body.style.cursor = "crosshair";
    function onMouseDown(e) {
      target = e.target;
      if (!target || target.closest("[data-backline-root]")) return;
      if (composerHasDraft()) {
        e.preventDefault();
        nudgeComposer();
        target = null;
        return;
      }
      e.preventDefault();
      if (interceptEvents) e.stopImmediatePropagation();
      isDrawing = true;
      startX = e.pageX;
      startY = e.pageY;
      overlay = document.createElement("div");
      overlay.className = "bl-region bl-region-draft";
      overlay.style.left = `${startX}px`;
      overlay.style.top = `${startY}px`;
      overlay.style.width = "0px";
      overlay.style.height = "0px";
      shadow.appendChild(overlay);
    }
    function onMouseMove(e) {
      if (!isDrawing || !overlay) return;
      const currentX = e.pageX;
      const currentY = e.pageY;
      const left = Math.min(startX, currentX);
      const top = Math.min(startY, currentY);
      const width = Math.abs(currentX - startX);
      const height = Math.abs(currentY - startY);
      overlay.style.left = `${left}px`;
      overlay.style.top = `${top}px`;
      overlay.style.width = `${width}px`;
      overlay.style.height = `${height}px`;
    }
    function onMouseUp() {
      if (!isDrawing || !overlay || !target) return;
      isDrawing = false;
      overlay.classList.remove("bl-region-draft");
      const finalLeft = parseFloat(overlay.style.left);
      const finalTop = parseFloat(overlay.style.top);
      const finalWidth = parseFloat(overlay.style.width);
      const finalHeight = parseFloat(overlay.style.height);
      if (finalWidth < 5 || finalHeight < 5) {
        overlay.remove();
        return;
      }
      const rect = { x: finalLeft, y: finalTop, width: finalWidth, height: finalHeight };
      const activeTarget = containerFor(target, rect);
      const pin = renderPin(shadow, finalLeft, finalTop);
      pin.classList.add("bl-pin-ghost");
      const targetRect = activeTarget.getBoundingClientRect();
      const offsetPct = {
        x: targetRect.width > 0 ? (finalLeft - (targetRect.left + window.scrollX)) / targetRect.width : 0,
        y: targetRect.height > 0 ? (finalTop - (targetRect.top + window.scrollY)) / targetRect.height : 0
      };
      const untrack = threadManager.trackPinPosition(pin, () => activeTarget, (box) => ({
        x: box.width * offsetPct.x,
        y: box.height * offsetPct.y
      }));
      const submission = createCommentSubmission(api, pageId, documentUrl);
      const activeOverlay = overlay;
      const controls = openComposer(
        shadow,
        finalLeft,
        finalTop + finalHeight,
        // open below the region
        async ({ body, attachments, tags }) => {
          try {
            const created = await submission.submit(async () => {
              controls.setStatus("Capturing region anchor + screenshot...");
              const anchor = await computeRegionAnchor(activeTarget, rect);
              const screenshotBlob = await screenshot();
              let screenshotKey = null;
              if (screenshotBlob) {
                controls.setStatus("Uploading screenshot...");
                screenshotKey = await uploadScreenshotFile(
                  api,
                  projectId,
                  screenshotBlob
                );
              }
              controls.setStatus("Posting comment...");
              const { browser: detectedBrowser, os, device_type: deviceType } = parseUserAgent(navigator.userAgent);
              const browser = browserOverride ?? detectedBrowser;
              return {
                body,
                layer: "client",
                anchor: { ...anchor, type: "region" },
                context: {
                  browser,
                  os,
                  device_type: deviceType,
                  viewport: { width: window.innerWidth, height: window.innerHeight },
                  url: window.location.href
                },
                screenshot_key: screenshotKey,
                capture_status: screenshotKey ? "ok" : "failed",
                attachments,
                tags
              };
            });
            pin.classList.remove("bl-pin-ghost");
            if (created.ticket_number != null) pin.textContent = String(created.ticket_number);
            ownCommentIds.add(created.id);
            threadManager.threadMessages.set(created.id, [created]);
            const tracked2 = threadManager.createRegionOverlay(created.anchor, () => activeTarget);
            if (tracked2) activeOverlay.remove();
            threadManager.adoptPin(
              created.id,
              pin,
              () => {
                untrack();
                tracked2?.untrack();
              },
              tracked2?.overlay ?? activeOverlay
            );
            threadManager.attachPinClickHandler(pin, created.id);
            tooltip.dismiss();
            if (created.capture_status === "failed") {
              controls.setStatus("Comment posted without an automatic screenshot. The text and location were saved.");
              controls.setCloseDelay(4e3);
            } else if (created.screenshot_url) {
              controls.setStatus("Comment posted with screenshot.");
            } else {
              controls.setStatus("Comment posted.");
            }
            onCommentCreated?.(created);
            return true;
          } catch (error) {
            controls.setRetryLocked(submission.isPrepared());
            throw error;
          }
        },
        () => {
          untrack();
          pin.remove();
          activeOverlay.remove();
        },
        (file) => uploadFile(api, projectId, file),
        composerDetails(`${Math.round(finalWidth)} \xD7 ${Math.round(finalHeight)}`)
      );
    }
    const suppressClick = (event) => {
      if (event.target?.closest("[data-backline-root]")) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    };
    if (interceptEvents) document.addEventListener("click", suppressClick, true);
    document.addEventListener("mousedown", onMouseDown, interceptEvents);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    return () => {
      if (interceptEvents) document.removeEventListener("click", suppressClick, true);
      document.removeEventListener("mousedown", onMouseDown, interceptEvents);
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = previousCursor;
    };
  }

  // src/lib/config.ts
  var API_BASE_URL = "https://backlinewidget-production.up.railway.app";
  var DASHBOARD_BASE_URL = "https://backline-qa.vercel.app";

  // src/lib/storage.ts
  var STORAGE_KEY = "backline:connection";
  async function getConnection() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    return result[STORAGE_KEY] ?? null;
  }

  // src/native-client.ts
  var NativeMessageError = class extends Error {
    constructor(message, status) {
      super(message);
      this.status = status;
    }
  };
  function reviewAccessEnded(error) {
    return error instanceof NativeMessageError && [401, 403, 404, 409].includes(error.status);
  }
  function reviewServiceUnavailable(error) {
    return error instanceof NativeMessageError && error.status === 503;
  }
  async function nativeMessage(type, fields = {}) {
    const result = await chrome.runtime.sendMessage({ type, ...fields });
    if (!result?.ok) throw new NativeMessageError(result?.error ?? "Reload this page to reconnect Backline.", Number(result?.status) || 0);
    return result.data;
  }
  function installDashboardBridge() {
    if (window.top !== window || location.origin !== new URL(DASHBOARD_BASE_URL).origin) return;
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== location.origin || event.data?.source !== "backline-dashboard") return;
      const { id, action, input } = event.data;
      if (typeof id !== "string" || !["status", "launch"].includes(action)) return;
      void nativeMessage(`native-review-${action}`, { input }).then(
        (data) => window.postMessage({ source: "backline-extension", id, ok: true, data }, location.origin),
        (error) => window.postMessage({ source: "backline-extension", id, ok: false, error: error.message, status: error instanceof NativeMessageError ? error.status : 0 }, location.origin)
      );
    });
  }
  function readData(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error("Could not read attachment."));
      reader.readAsDataURL(blob);
    });
  }
  function createNativeApi(pageUrl) {
    return {
      request: async (path, init = {}) => {
        if (init.method === "POST" && path.endsWith("/comments") && location.href !== pageUrl) {
          throw new Error("The page changed. Cancel this draft and comment on the new page.");
        }
        return nativeMessage("native-review-api", { path, method: init.method ?? "GET", body: init.body });
      },
      upload: async (_path, form) => {
        const file = form.get("file");
        if (!(file instanceof File)) throw new Error("Choose a file to upload.");
        if (file.size > 2e7) throw new Error("Choose a file smaller than 20 MB.");
        return nativeMessage("native-review-upload", { file: { data: await readData(file), type: file.type, name: file.name } });
      }
    };
  }
  async function uploadNativeScreenshot(api, projectId, screenshot) {
    const form = new FormData();
    form.append("project_id", projectId);
    form.append("file", screenshot, "screenshot.jpg");
    try {
      return (await api.upload("/api/v1/uploads/direct", form)).key;
    } catch {
      return null;
    }
  }
  async function uploadNativeAttachment(api, projectId, file) {
    const form = new FormData();
    form.append("project_id", projectId);
    form.append("file", file);
    try {
      const { key } = await api.upload("/api/v1/uploads/direct", form);
      return { key, filename: file.name, content_type: file.type || "application/octet-stream" };
    } catch {
      return null;
    }
  }
  async function captureNativeScreenshot() {
    const hosts = Array.from(document.querySelectorAll("[data-backline-root]"));
    const prior = hosts.map((host) => host.style.visibility);
    hosts.forEach((host) => {
      host.style.visibility = "hidden";
    });
    try {
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
      const data = await nativeMessage("native-review-capture", { url: location.href });
      const binary = atob(data.split(",")[1]);
      return new Blob([Uint8Array.from(binary, (char) => char.charCodeAt(0))], { type: "image/jpeg" });
    } catch {
      return null;
    } finally {
      hosts.forEach((host, i) => {
        host.style.visibility = prior[i];
      });
    }
  }

  // src/native-toolbar.ts
  function createNativeToolbar(info, onMode, onEnd) {
    const shadow = createShadowRoot();
    const style = document.createElement("style");
    style.textContent = `
    .native-bar {position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483647;
      display:flex;flex-wrap:wrap;align-items:center;gap:6px;max-width:calc(100vw - 24px);width:max-content;
      background:#fff;color:#0b0b0b;border:1px solid #dddeda;border-radius:12px;padding:10px;box-shadow:0 5px 30px #0003;font:13px system-ui;}
    .native-bar button,.native-bar a {font:inherit;border:1px solid #dddeda;border-radius:7px;padding:8px 10px;background:#fff;color:#0b0b0b;cursor:pointer;text-decoration:none;}
    .native-bar button[aria-pressed=true] {background:#e3f8ef;border-color:#0a6b4b;}
    .native-status {flex-basis:100%;font-size:12px;max-width:530px;color:#515650;}
    .native-title {max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0 8px;}
  `;
    shadow.appendChild(style);
    const bar = document.createElement("div");
    bar.className = "native-bar";
    bar.setAttribute("role", "toolbar");
    bar.setAttribute("aria-label", "Backline browser review");
    const title = document.createElement("strong");
    title.className = "native-title";
    title.textContent = info.project.name;
    bar.appendChild(title);
    const buttons = /* @__PURE__ */ new Map();
    const status = document.createElement("div");
    let accessEnded = false;
    let removed = false;
    let changingMode = false;
    status.className = "native-status";
    status.setAttribute("role", "status");
    function setMode(mode) {
      if (accessEnded || removed) return;
      buttons.forEach((button, key) => button.setAttribute("aria-pressed", String(key === mode)));
      status.textContent = mode === "browse" ? "Browse and sign in normally. Choose Comment when you're ready." : mode === "point" ? "Click an element to leave a comment." : "Drag over an area to leave a comment.";
    }
    for (const [mode, label] of [["browse", "Browse"], ["point", "Comment"], ["region", "Draw"]]) {
      const button = document.createElement("button");
      button.textContent = label;
      button.onclick = () => {
        if (changingMode || accessEnded || removed) return;
        changingMode = true;
        buttons.forEach((item) => {
          item.disabled = true;
        });
        void onMode(mode).then(() => setMode(mode), (error) => {
          if (!accessEnded && !removed) status.textContent = error.message;
        }).finally(() => {
          changingMode = false;
          if (!accessEnded && !removed) buttons.forEach((item) => {
            item.disabled = false;
          });
        });
      };
      buttons.set(mode, button);
      bar.appendChild(button);
    }
    const back = document.createElement("button");
    back.textContent = "Return to Backline";
    back.onclick = () => {
      void nativeMessage("native-review-return").catch((error) => {
        status.textContent = error.message;
      });
    };
    bar.appendChild(back);
    const end = document.createElement("button");
    end.textContent = "Close website tools";
    end.onclick = () => {
      void onEnd().then(remove, (error) => {
        status.textContent = error.message;
      });
    };
    bar.appendChild(end);
    bar.appendChild(status);
    shadow.appendChild(bar);
    setMode("browse");
    const reserveToolbarSpace = () => {
      const rect = bar.getBoundingClientRect();
      if (rect.height > 0) setCardBottomInset(window.innerHeight - rect.top + 12);
    };
    const observer = new ResizeObserver(reserveToolbarSpace);
    observer.observe(bar);
    reserveToolbarSpace();
    function remove() {
      if (removed) return;
      removed = true;
      observer.disconnect();
      shadow.host.remove();
      setCardBottomInset(12);
    }
    return {
      setMode,
      remove,
      error: (message) => {
        if (!accessEnded && !removed) status.textContent = message;
      },
      endAccess: (message) => {
        accessEnded = true;
        title.textContent = "Backline";
        buttons.forEach((button) => {
          button.disabled = true;
          button.setAttribute("aria-pressed", "false");
        });
        status.textContent = message;
      }
    };
  }

  // src/content-script.ts
  var context = null;
  var building = null;
  var contextGeneration = 0;
  var toolbar = null;
  var nativeInfo = null;
  var currentMode = null;
  var deactivateCurrentMode = null;
  var nativeAccessClosed = false;
  function endNativeAccess() {
    nativeAccessClosed = true;
    clearContext();
    nativeInfo = null;
    toolbar?.endAccess("Review access ended. Loaded feedback and drafts have been cleared. Return to Backline to sign in or reopen an available review.");
  }
  async function buildContext() {
    if (context) return context;
    if (building) return building;
    building = buildFreshContext();
    try {
      return await building;
    } finally {
      building = null;
    }
  }
  async function buildFreshContext() {
    const pageUrl = location.href;
    const generation = contextGeneration;
    const info = nativeInfo;
    const connection = info ? null : await getConnection();
    if (!info && !connection) throw new Error("Open this project's Browser review button in Backline first.");
    const api = info ? createNativeApi(pageUrl) : createApiClient(API_BASE_URL, () => ({
      Authorization: `Bearer ${connection.token}`
    }));
    const project = info?.project ?? await api.request(
      `/api/v1/workspaces/${connection.workspaceId}/projects/resolve`,
      { method: "POST", body: JSON.stringify({ target_origin: window.location.origin }) }
    );
    const pageId = await registerCurrentPage(api, project.id, pageUrl);
    const existingComments = await api.request(`/api/v1/pages/${pageId}/comments`);
    if (generation !== contextGeneration || location.href !== pageUrl) throw new Error("The page changed. Choose Comment again when it finishes loading.");
    const shadow = createShadowRoot();
    capturePageVersion(api, pageId, shadow, pageUrl);
    const address = new URL(pageUrl);
    const route = address.hash.startsWith("#/") || address.hash.startsWith("#!/") ? address.hash : "";
    const pagePath = address.pathname + address.search + route;
    const threadManager = createThreadManager({
      shadow,
      pagePath: () => pagePath,
      statusUpdater: () => info && !info.member || !["editor", "manager"].includes(project.my_role ?? "") ? null : async (commentId, status) => {
        const updated = await api.request(`/api/v1/comments/${commentId}`, {
          method: "PATCH",
          body: JSON.stringify({ status })
        });
        return updated.status;
      },
      replyPoster: () => info && !info.member ? (topId, request) => postThreadReply(api, topId, request) : ["commenter", "editor", "manager"].includes(project.my_role ?? "") ? (topId, request) => postThreadReply(api, topId, request) : null
    });
    for (const top of existingComments.filter((c) => c.parent_id === null)) {
      threadManager.addThread(top, existingComments.filter((c) => c.parent_id === top.id).sort((a, b) => a.created_at.localeCompare(b.created_at)));
    }
    context = {
      api,
      shadow,
      project,
      pageId,
      pageUrl,
      native: !!info,
      threadManager,
      ownCommentIds: /* @__PURE__ */ new Set(),
      tooltip: showTooltip(shadow),
      // The connection only carries the member's email, so the composer's avatar
      // initials come from that.
      composerDetails: (regionSize) => ({
        authorName: info?.authorName ?? connection.userEmail,
        pagePath,
        browser: parseUserAgent(navigator.userAgent).browser,
        regionSize
      })
    };
    return context;
  }
  function activatePointMode(ctx) {
    const { api, shadow, project, pageId, threadManager, ownCommentIds, tooltip, composerDetails } = ctx;
    const { threadMessages, pinsByTopId, trackPinPosition, attachPinClickHandler } = threadManager;
    const handleClick = (event) => {
      const target = event.target;
      if (!target || target.closest("[data-backline-root]")) return;
      if (composerHasDraft()) {
        event.preventDefault();
        event.stopImmediatePropagation();
        nudgeComposer();
        return;
      }
      event.preventDefault();
      event.stopImmediatePropagation();
      const x = event.pageX;
      const y = event.pageY;
      const pin = renderPin(shadow, x, y);
      pin.classList.add("bl-pin-ghost");
      const targetRect = target.getBoundingClientRect();
      const offset = {
        x: x - (targetRect.left + window.scrollX),
        y: y - (targetRect.top + window.scrollY)
      };
      const untrack = trackPinPosition(pin, () => target, offset);
      const submission = createCommentSubmission(api, pageId, ctx.pageUrl);
      const controls = openComposer(
        shadow,
        x,
        y,
        async ({ body, attachments, tags }) => {
          try {
            const created = await submission.submit(async () => {
              controls.setStatus("Capturing anchor + screenshot...");
              const anchor = await computeAnchor(target, x, y);
              const screenshotBlob = await (ctx.native ? captureNativeScreenshot() : captureScreenshot());
              let screenshotKey = null;
              if (screenshotBlob) {
                controls.setStatus("Uploading screenshot...");
                screenshotKey = ctx.native ? await uploadNativeScreenshot(api, project.id, screenshotBlob) : await uploadScreenshot(api, project.id, screenshotBlob);
              }
              controls.setStatus("Posting comment...");
              const { browser, os, device_type: deviceType } = parseUserAgent(navigator.userAgent);
              return {
                body,
                layer: "client",
                anchor: { ...anchor, type: "point" },
                context: {
                  browser,
                  os,
                  device_type: deviceType,
                  viewport: { width: window.innerWidth, height: window.innerHeight },
                  url: window.location.href
                },
                screenshot_key: screenshotKey,
                capture_status: screenshotKey ? "ok" : "failed",
                attachments,
                tags
              };
            });
            pin.classList.remove("bl-pin-ghost");
            if (created.ticket_number != null) pin.textContent = String(created.ticket_number);
            ownCommentIds.add(created.id);
            threadMessages.set(created.id, [created]);
            pinsByTopId.set(created.id, { pin, untrack });
            attachPinClickHandler(pin, created.id);
            tooltip.dismiss();
            if (created.capture_status === "failed") {
              controls.setStatus("Comment posted without an automatic screenshot. The text and location were saved.");
              controls.setCloseDelay(4e3);
            } else if (created.screenshot_url) {
              controls.setStatus("Comment posted with screenshot.");
            } else {
              controls.setStatus("Comment posted.");
            }
            return true;
          } catch (error) {
            controls.setRetryLocked(submission.isPrepared());
            throw error;
          }
        },
        () => {
          untrack();
          pin.remove();
        },
        (file) => ctx.native ? uploadNativeAttachment(api, project.id, file) : uploadAttachment(api, project.id, file),
        composerDetails()
      );
    };
    document.addEventListener("click", handleClick, true);
    return () => document.removeEventListener("click", handleClick, true);
  }
  async function activate(mode) {
    if (nativeAccessClosed) throw new Error("Review access ended. Return to Backline and open the review again.");
    if (currentMode === mode) return;
    const ctx = await buildContext();
    if (!ctx) return;
    if ((!ctx.native || nativeInfo?.member) && !["commenter", "editor", "manager"].includes(ctx.project.my_role ?? "")) {
      throw new Error("This project is read-only for your account. Return to Backline to view its feedback.");
    }
    deactivateCurrentMode?.();
    ctx.shadow.host.style.display = "";
    currentMode = mode;
    if (mode === "region") {
      deactivateCurrentMode = setupRegionDrawer({
        shadow: ctx.shadow,
        api: ctx.api,
        projectId: ctx.project.id,
        pageId: ctx.pageId,
        documentUrl: ctx.pageUrl,
        browserOverride: null,
        threadManager: ctx.threadManager,
        ownCommentIds: ctx.ownCommentIds,
        tooltip: ctx.tooltip,
        composerDetails: ctx.composerDetails,
        screenshot: ctx.native ? captureNativeScreenshot : captureScreenshot,
        uploadScreenshotFile: ctx.native ? uploadNativeScreenshot : uploadScreenshot,
        uploadFile: ctx.native ? uploadNativeAttachment : uploadAttachment,
        interceptEvents: true
      });
    } else {
      deactivateCurrentMode = activatePointMode(ctx);
    }
  }
  function browse() {
    cancelEmptyComposer();
    deactivateCurrentMode?.();
    deactivateCurrentMode = null;
    currentMode = null;
    if (context) context.shadow.host.style.display = "none";
  }
  function clearContext() {
    contextGeneration += 1;
    discardComposerForTeardown();
    browse();
    context?.threadManager.clearPage();
    context?.tooltip.dismiss();
    context?.shadow.host.remove();
    context = null;
  }
  async function startNativeReview() {
    const info = await nativeMessage("native-review-info");
    if (!info) return;
    if (composerHasDraft()) throw new Error("Finish or cancel your current comment first.");
    clearContext();
    toolbar?.remove();
    nativeAccessClosed = false;
    nativeInfo = info;
    toolbar = createNativeToolbar(info, async (mode) => {
      if (nativeInfo !== info) throw new Error("This review changed. Open it again from Backline.");
      if (composerHasDraft()) throw new Error("Finish or cancel your current comment first.");
      if (mode === "browse") browse();
      else await activate(mode);
    }, async () => {
      if (composerHasDraft()) throw new Error("Finish or cancel your current comment first.");
      const closingToolbar = toolbar;
      await nativeMessage("native-review-end", { launchId: info.launchId });
      if (toolbar !== closingToolbar) return;
      clearContext();
      nativeInfo = null;
      toolbar = null;
    });
    try {
      await nativeMessage("native-review-ready", { launchId: info.launchId });
    } catch (error) {
      if (reviewServiceUnavailable(error)) {
        toolbar?.error("Backline is temporarily unavailable. Keep this tab open; the toolbar will retry when the service returns.");
        return;
      }
      clearContext();
      toolbar?.remove();
      toolbar = null;
      nativeInfo = null;
      throw error;
    }
  }
  var isolatedWindow = window;
  if (!isolatedWindow.__backlineExtensionLoaded && window.top === window) {
    isolatedWindow.__backlineExtensionLoaded = true;
    installDashboardBridge();
    chrome.runtime.onMessage.addListener((message, _sender, respond) => {
      const action = message.type === "native-review-start" ? startNativeReview() : message.type === "native-review-stop" ? Promise.resolve().then(() => {
        clearContext();
        toolbar?.remove();
        toolbar = null;
        nativeInfo = null;
      }) : message.type === "activate-annotation" ? activate(message.mode) : null;
      if (!action) return false;
      void action.then(() => respond({ ok: true }), (error) => {
        toolbar?.error(error.message);
        respond({ ok: false, error: error.message });
      });
      return true;
    });
    void startNativeReview().catch(() => {
    });
    setInterval(() => {
      if (context && location.href !== context.pageUrl && !composerHasDraft()) {
        clearContext();
        toolbar?.setMode("browse");
      }
    }, 500);
    let commentsLoading = false;
    setInterval(() => {
      const ctx = context;
      if (commentsLoading || !ctx || !ctx.native || document.hidden || composerHasDraft() || location.href !== ctx.pageUrl) return;
      commentsLoading = true;
      void ctx.api.request(`/api/v1/pages/${ctx.pageId}/comments`).then((comments) => {
        if (context !== ctx) return;
        const ids = new Set(comments.map((comment) => comment.id));
        for (const id of ctx.threadManager.threadMessages.keys()) {
          if (!ids.has(id)) ctx.threadManager.handleCommentDeleted(id, id);
        }
        for (const comment of comments) {
          ctx.threadManager.handleCommentCreated(comment, ctx.pageId);
          ctx.threadManager.handleCommentUpdated(comment);
        }
      }).catch((error) => {
        if (context !== ctx) return;
        if (reviewAccessEnded(error)) endNativeAccess();
        else toolbar?.error(error.message);
      }).finally(() => {
        commentsLoading = false;
      });
    }, 1e4);
    let checkingAccess = false;
    async function checkNativeAccess() {
      const info = nativeInfo;
      if (checkingAccess || !info || nativeAccessClosed || document.hidden) return;
      checkingAccess = true;
      try {
        const result = await nativeMessage("native-review-check-access");
        if (nativeInfo !== info || result.launchId !== info.launchId) return;
        const previousRole = info.project.my_role;
        info.project = result.project;
        if (context?.native) context.project = { ...context.project, ...result.project };
        if (!currentMode) toolbar?.setMode("browse");
        if (previousRole !== result.project.my_role && context?.native) {
          clearContext();
          toolbar?.setMode("browse");
          toolbar?.error("Your project role changed. Loaded feedback and drafts were cleared. Check Backline for any save that was in progress, then reopen tools with your current access.");
        }
      } catch (error) {
        if (nativeInfo !== info) return;
        if (reviewAccessEnded(error)) endNativeAccess();
        else toolbar?.error("Could not confirm review access. Check your connection; access will be checked again.");
      } finally {
        checkingAccess = false;
      }
    }
    setInterval(() => {
      void checkNativeAccess();
    }, 3e4);
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) void checkNativeAccess();
    });
    window.addEventListener("focus", () => {
      void checkNativeAccess();
    });
  }
})();
